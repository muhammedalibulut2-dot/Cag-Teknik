package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.AppNotification
import com.example.data.model.FieldStaffMember
import com.example.data.model.PartOrderRequest
import com.example.data.model.SparePartItem

@Database(
    entities = [PartOrderRequest::class, AppNotification::class, SparePartItem::class, FieldStaffMember::class],
    version = 3,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun partOrderDao(): PartOrderDao
    abstract fun notificationDao(): NotificationDao
    abstract fun sparePartDao(): SparePartDao
    abstract fun fieldStaffDao(): FieldStaffDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "parca_takip_database"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
