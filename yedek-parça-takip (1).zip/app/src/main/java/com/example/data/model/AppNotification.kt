package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "app_notifications")
data class AppNotification(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val orderId: Long,
    val customerName: String,
    val technicianId: String = "tech_01",
    val title: String,
    val message: String,
    val type: String, // "SIPARIS_GECILDI", "TESLIM_EDILDI", "YENI_TALEP"
    val timestamp: Long = System.currentTimeMillis(),
    val isRead: Boolean = false
)
