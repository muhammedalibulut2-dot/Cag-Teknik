package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.FieldStaffMember
import kotlinx.coroutines.flow.Flow

@Dao
interface FieldStaffDao {
    @Query("SELECT * FROM field_staff_members ORDER BY fullName ASC")
    fun getAllStaff(): Flow<List<FieldStaffMember>>

    @Query("SELECT * FROM field_staff_members WHERE isActive = 1 ORDER BY fullName ASC")
    fun getActiveStaff(): Flow<List<FieldStaffMember>>

    @Query("SELECT * FROM field_staff_members WHERE LOWER(username) = LOWER(:username) LIMIT 1")
    suspend fun findStaffByUsername(username: String): FieldStaffMember?

    @Query("SELECT * FROM field_staff_members WHERE id = :id")
    suspend fun getStaffById(id: Long): FieldStaffMember?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStaff(staff: FieldStaffMember): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStaffList(staffList: List<FieldStaffMember>)

    @Update
    suspend fun updateStaff(staff: FieldStaffMember)

    @Delete
    suspend fun deleteStaff(staff: FieldStaffMember)

    @Query("DELETE FROM field_staff_members WHERE id = :id")
    suspend fun deleteStaffById(id: Long)

    @Query("DELETE FROM field_staff_members")
    suspend fun deleteAllStaff()

    @Query("SELECT COUNT(*) FROM field_staff_members")
    suspend fun getStaffCount(): Int
}
