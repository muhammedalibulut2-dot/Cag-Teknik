package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "part_order_requests")
data class PartOrderRequest(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val customerName: String,
    val customerPhone: String,
    val customerAddress: String,
    val deviceType: String,
    val deviceModel: String,
    val deviceSerial: String = "",
    val faultDescription: String,
    val devicePhotoUri: String? = null,
    val requiredPartName: String,
    val requiredPartCode: String = "",
    val requiredPartDescription: String = "",
    val requiredPartPhotoUri: String? = null,
    val partQuantity: Int = 1,
    val isStockDeducted: Boolean = false,
    val technicianName: String = "Ahmet Yılmaz (Saha 1)",
    val technicianId: String = "tech_01",
    val status: String = OrderStatus.PENDING,
    // Fields updated by Ana Hesap when order is placed
    val orderPlacedAt: Long? = null,
    val orderSupplier: String? = null,
    val orderRefNumber: String? = null,
    val orderNotes: String? = null,
    // Fields updated by Ana Hesap when part arrives / delivered
    val arrivedAt: Long? = null,
    val arrivedPartPhotoUri: String? = null,
    val arrivalNotes: String? = null,
    // Overdue tracking & 3-day snooze
    val snoozedUntil: Long? = null,
    val lastOverdueNotifiedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
) {
    companion object {
        const val THREE_DAYS_MS = 3 * 24 * 3600 * 1000L // 3 days in milliseconds
    }

    val isOverdue: Boolean
        get() {
            if (status == OrderStatus.DELIVERED) return false
            val startPoint = orderPlacedAt ?: createdAt
            return (System.currentTimeMillis() - startPoint) >= THREE_DAYS_MS
        }

    val isSnoozed: Boolean
        get() = snoozedUntil != null && System.currentTimeMillis() < snoozedUntil

    val overdueDaysCount: Int
        get() {
            if (status == OrderStatus.DELIVERED) return 0
            val startPoint = orderPlacedAt ?: createdAt
            val elapsedMs = System.currentTimeMillis() - startPoint
            return ((elapsedMs / (24 * 3600 * 1000L))).toInt()
        }
}
