package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.SparePartItem
import kotlinx.coroutines.flow.Flow

@Dao
interface SparePartDao {
    @Query("SELECT * FROM spare_parts_inventory ORDER BY partName ASC")
    fun getAllParts(): Flow<List<SparePartItem>>

    @Query("SELECT * FROM spare_parts_inventory WHERE stockQuantity <= minCriticalLevel ORDER BY stockQuantity ASC")
    fun getCriticalParts(): Flow<List<SparePartItem>>

    @Query("SELECT * FROM spare_parts_inventory WHERE partName LIKE '%' || :query || '%' OR partCode LIKE '%' || :query || '%' ORDER BY partName ASC")
    fun searchParts(query: String): Flow<List<SparePartItem>>

    @Query("SELECT * FROM spare_parts_inventory WHERE id = :id")
    suspend fun getPartById(id: Long): SparePartItem?

    @Query("SELECT * FROM spare_parts_inventory WHERE partCode = :code OR partName = :name LIMIT 1")
    suspend fun findPartByCodeOrName(code: String, name: String): SparePartItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPart(part: SparePartItem): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertParts(parts: List<SparePartItem>)

    @Update
    suspend fun updatePart(part: SparePartItem)

    @Query("UPDATE spare_parts_inventory SET stockQuantity = CASE WHEN stockQuantity >= :amount THEN stockQuantity - :amount ELSE 0 END, lastUpdated = :now WHERE id = :id")
    suspend fun decrementStock(id: Long, amount: Int, now: Long = System.currentTimeMillis())

    @Query("UPDATE spare_parts_inventory SET stockQuantity = stockQuantity + :amount, lastUpdated = :now WHERE id = :id")
    suspend fun incrementStock(id: Long, amount: Int, now: Long = System.currentTimeMillis())

    @Delete
    suspend fun deletePart(part: SparePartItem)

    @Query("SELECT COUNT(*) FROM spare_parts_inventory")
    suspend fun getPartCount(): Int
}
