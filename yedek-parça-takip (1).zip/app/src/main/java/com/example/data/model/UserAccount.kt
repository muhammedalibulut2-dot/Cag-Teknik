package com.example.data.model

data class UserAccount(
    val username: String,
    val passwordHash: String,
    val fullName: String,
    val role: UserRole,
    val technicianId: String? = null,
    val phone: String = ""
)

object PredefinedAccounts {
    val accounts = emptyList<UserAccount>()

    fun authenticate(username: String, password: String): UserAccount? {
        val cleanUser = username.trim().lowercase()
        val cleanPass = password.trim()
        return accounts.find { it.username.lowercase() == cleanUser && it.passwordHash == cleanPass }
    }
}
