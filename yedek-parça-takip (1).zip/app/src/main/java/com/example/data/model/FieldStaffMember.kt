package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "field_staff_members")
data class FieldStaffMember(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val staffId: String,
    val fullName: String,
    val username: String,
    val password: String,
    val phone: String = "",
    val title: String = "Saha Teknisyeni",
    val isActive: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
