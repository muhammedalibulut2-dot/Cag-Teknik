package com.example.data.firebase

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.util.Log
import com.example.data.model.OrderStatus
import com.example.data.model.PartOrderRequest
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

class FirestoreSyncManager(private val context: Context) {

    private val candidateApiBases = listOf(
        "http://10.0.2.2:3000/api",
        "https://ais-dev-m6jbq5bvnlkcobxbckdazl-80995006174.europe-west2.run.app/api",
        "http://10.0.2.2:8080/api",
        "http://127.0.0.1:3000/api",
        "https://ais-pre-m6jbq5bvnlkcobxbckdazl-80995006174.europe-west2.run.app/api"
    )
    private val scope = CoroutineScope(Dispatchers.IO)

    fun isOnline(): Boolean {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager ?: return false
            val network = cm.activeNetwork ?: return false
            val caps = cm.getNetworkCapabilities(network) ?: return false
            caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
        } catch (e: Exception) {
            false
        }
    }

    fun syncOrder(order: PartOrderRequest, onComplete: ((Boolean) -> Unit)? = null) {
        scope.launch {
            if (!isOnline()) {
                Log.w("SyncManager", "Device is offline. Order #${order.id} will remain in local cache.")
                withContext(Dispatchers.Main) { onComplete?.invoke(false) }
                return@launch
            }

            val success = sendOrderToApi(order)
            withContext(Dispatchers.Main) { onComplete?.invoke(success) }
        }
    }

    private fun sendOrderToApi(order: PartOrderRequest): Boolean {
        for (baseUrl in candidateApiBases) {
            try {
                val url = URL("$baseUrl/orders")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "POST"
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8")
                conn.connectTimeout = 3000
                conn.readTimeout = 3000
                conn.doOutput = true

                val json = JSONObject().apply {
                    put("id", order.id)
                    put("customerName", order.customerName)
                    put("customerPhone", order.customerPhone)
                    put("customerAddress", order.customerAddress)
                    put("deviceType", order.deviceType)
                    put("deviceModel", order.deviceModel)
                    put("deviceSerial", order.deviceSerial)
                    put("faultDescription", order.faultDescription)
                    put("requiredPartName", order.requiredPartName)
                    put("requiredPartCode", order.requiredPartCode)
                    put("requiredPartPhotoUri", order.requiredPartPhotoUri ?: "")
                    put("partQuantity", order.partQuantity)
                    put("technicianName", order.technicianName)
                    put("technicianId", order.technicianId)
                    put("status", order.status)
                    put("createdAt", order.createdAt)
                    put("orderPlacedAt", order.orderPlacedAt ?: JSONObject.NULL)
                    put("arrivedAt", order.arrivedAt ?: JSONObject.NULL)
                }

                OutputStreamWriter(conn.outputStream).use { it.write(json.toString()) }
                val code = conn.responseCode
                conn.disconnect()
                if (code in 200..299) {
                    Log.d("SyncManager", "Order #${order.id} synced via $baseUrl")
                    return true
                }
            } catch (e: Exception) {
                // Try next endpoint
            }
        }
        return false
    }

    fun startPollingOrders(onOrdersUpdated: (List<PartOrderRequest>) -> Unit) {
        scope.launch {
            while (isActive) {
                if (isOnline()) {
                    try {
                        val orders = fetchOrdersFromApi()
                        if (orders.isNotEmpty()) {
                            withContext(Dispatchers.Main) {
                                onOrdersUpdated(orders)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("SyncManager", "Fetch poll error: ${e.message}")
                    }
                }
                delay(2500) // Poll every 2.5 seconds
            }
        }
    }

    private fun fetchOrdersFromApi(): List<PartOrderRequest> {
        for (baseUrl in candidateApiBases) {
            try {
                val url = URL("$baseUrl/orders")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 3000
                conn.readTimeout = 3000

                if (conn.responseCode in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val sb = StringBuilder()
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        sb.append(line)
                    }
                    reader.close()
                    conn.disconnect()

                    val text = sb.toString().trim()
                    if (text.startsWith("[")) {
                        val list = mutableListOf<PartOrderRequest>()
                        val jsonArr = JSONArray(text)
                        for (i in 0 until jsonArr.length()) {
                            val obj = jsonArr.getJSONObject(i)
                            list.add(
                                PartOrderRequest(
                                    id = obj.optLong("id", System.currentTimeMillis()),
                                    customerName = obj.optString("customerName", "Müşteri"),
                                    customerPhone = obj.optString("customerPhone", ""),
                                    customerAddress = obj.optString("customerAddress", ""),
                                    deviceType = obj.optString("deviceType", "Cihaz"),
                                    deviceModel = obj.optString("deviceModel", ""),
                                    deviceSerial = obj.optString("deviceSerial", ""),
                                    faultDescription = obj.optString("faultDescription", ""),
                                    requiredPartName = obj.optString("requiredPartName", "Parça"),
                                    requiredPartCode = obj.optString("requiredPartCode", ""),
                                    requiredPartPhotoUri = obj.optString("requiredPartPhotoUri", "").ifBlank { null },
                                    partQuantity = obj.optInt("partQuantity", 1),
                                    technicianName = obj.optString("technicianName", "Saha Personeli"),
                                    technicianId = obj.optString("technicianId", "tech_01"),
                                    status = obj.optString("status", OrderStatus.PENDING),
                                    createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                                    orderPlacedAt = if (obj.has("orderPlacedAt") && !obj.isNull("orderPlacedAt")) obj.optLong("orderPlacedAt") else null,
                                    arrivedAt = if (obj.has("arrivedAt") && !obj.isNull("arrivedAt")) obj.optLong("arrivedAt") else null
                                )
                            )
                        }
                        if (list.isNotEmpty()) return list
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                // Try next endpoint
            }
        }
        return emptyList()
    }

    fun fetchUsersFromApi(): List<com.example.data.model.UserAccount> {
        for (baseUrl in candidateApiBases) {
            try {
                val url = URL("$baseUrl/users")
                val conn = url.openConnection() as HttpURLConnection
                conn.requestMethod = "GET"
                conn.connectTimeout = 3000
                conn.readTimeout = 3000

                if (conn.responseCode in 200..299) {
                    val reader = BufferedReader(InputStreamReader(conn.inputStream))
                    val sb = StringBuilder()
                    var line: String?
                    while (reader.readLine().also { line = it } != null) {
                        sb.append(line)
                    }
                    reader.close()
                    conn.disconnect()

                    val text = sb.toString().trim()
                    if (text.startsWith("[")) {
                        val list = mutableListOf<com.example.data.model.UserAccount>()
                        val jsonArr = JSONArray(text)
                        for (i in 0 until jsonArr.length()) {
                            val obj = jsonArr.getJSONObject(i)
                            val roleStr = obj.optString("role", "TECHNICIAN")
                            val role = if (roleStr.equals("HEADQUARTERS", ignoreCase = true)) com.example.data.model.UserRole.HEADQUARTERS else com.example.data.model.UserRole.TECHNICIAN
                            list.add(
                                com.example.data.model.UserAccount(
                                    username = obj.optString("username", ""),
                                    passwordHash = obj.optString("password", "123"),
                                    fullName = obj.optString("fullName", "Teknisyen"),
                                    role = role,
                                    technicianId = obj.optString("technicianId", "tech_01"),
                                    phone = obj.optString("phone", "")
                                )
                            )
                        }
                        if (list.isNotEmpty()) return list
                    }
                }
                conn.disconnect()
            } catch (e: Exception) {
                // Try next endpoint
            }
        }
        return emptyList()
    }

    fun startPollingUsers(onUsersUpdated: (List<com.example.data.model.UserAccount>) -> Unit) {
        scope.launch {
            while (isActive) {
                if (isOnline()) {
                    try {
                        val remoteUsers = fetchUsersFromApi()
                        if (remoteUsers.isNotEmpty()) {
                            withContext(Dispatchers.Main) {
                                onUsersUpdated(remoteUsers)
                            }
                        }
                    } catch (e: Exception) {
                        Log.w("SyncManager", "Users poll error: ${e.message}")
                    }
                }
                delay(2000) // Poll users every 2 seconds for immediate synchronization
            }
        }
    }

    fun syncStock(item: Any? = null) {
        // Stock tracking removed as per user requirement
    }
}
