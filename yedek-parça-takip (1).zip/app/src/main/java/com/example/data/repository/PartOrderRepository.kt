package com.example.data.repository

import android.content.Context
import com.example.data.local.AppDatabase
import com.example.data.model.AppNotification
import com.example.data.model.OrderStatus
import com.example.data.model.PartOrderRequest
import com.example.data.model.SparePartItem
import com.example.util.NotificationHelper
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.launch

data class TechnicianPerformance(
    val technicianId: String,
    val technicianName: String,
    val totalOrders: Int,
    val completedOrders: Int,
    val pendingOrders: Int,
    val avgCompletionTimeHours: Double,
    val avgCompletionTimeFormatted: String
)

class PartOrderRepository(
    private val context: Context,
    private val database: AppDatabase = AppDatabase.getDatabase(context)
) {
    private val partOrderDao = database.partOrderDao()
    private val notificationDao = database.notificationDao()
    private val sparePartDao = database.sparePartDao()
    private val fieldStaffDao = database.fieldStaffDao()
    private val firestoreSync = com.example.data.firebase.FirestoreSyncManager(context)

    val allOrders: Flow<List<PartOrderRequest>> = partOrderDao.getAllOrders()
    val allNotifications: Flow<List<AppNotification>> = notificationDao.getAllNotifications()
    val unreadCount: Flow<Int> = notificationDao.getUnreadCount()

    // Field Staff streams
    val allStaff: Flow<List<com.example.data.model.FieldStaffMember>> = fieldStaffDao.getAllStaff()
    val activeStaff: Flow<List<com.example.data.model.FieldStaffMember>> = fieldStaffDao.getActiveStaff()

    // Stock streams
    val allSpareParts: Flow<List<SparePartItem>> = sparePartDao.getAllParts()
    val criticalSpareParts: Flow<List<SparePartItem>> = sparePartDao.getCriticalParts()

    init {
        firestoreSync.startPollingOrders { remoteOrders ->
            kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
                remoteOrders.forEach { remote ->
                    val existing = partOrderDao.getOrderByIdDirect(remote.id)
                    if (existing == null) {
                        partOrderDao.insertOrder(remote)
                    } else if (existing.status != remote.status) {
                        partOrderDao.updateOrder(existing.copy(
                            status = remote.status,
                            orderPlacedAt = remote.orderPlacedAt ?: existing.orderPlacedAt,
                            arrivedAt = remote.arrivedAt ?: existing.arrivedAt
                        ))
                        val statusLabel = if (remote.status == "ONAYLANDI") "Merkez tarafından onaylandı." else "Durum: ${remote.status}"
                        NotificationHelper.showSystemNotification(
                            context = context,
                            notificationId = (remote.id % 100000).toInt(),
                            title = "✅ Sipariş Durumu Güncellendi",
                            message = "‘${remote.requiredPartName}’ talebiniz $statusLabel",
                            orderId = remote.id
                        )
                    }
                }
            }
        }
    }

    fun getOrderById(id: Long): Flow<PartOrderRequest?> = partOrderDao.getOrderById(id)

    suspend fun findPartByCodeOrName(code: String, name: String): SparePartItem? {
        return sparePartDao.findPartByCodeOrName(code.trim(), name.trim())
    }

    suspend fun createOrder(order: PartOrderRequest): Long {
        val insertedId = partOrderDao.insertOrder(order)

        // If stock deduction is requested, decrement from inventory
        if (order.isStockDeducted && order.requiredPartName.isNotBlank()) {
            val matchingPart = sparePartDao.findPartByCodeOrName(order.requiredPartCode, order.requiredPartName)
            if (matchingPart != null && matchingPart.stockQuantity > 0) {
                sparePartDao.decrementStock(matchingPart.id, order.partQuantity)
            }
        }

        val notification = AppNotification(
            orderId = insertedId,
            customerName = order.customerName,
            technicianId = order.technicianId,
            title = "Yeni Talep Alındı",
            message = "‘${order.customerName}’ müşterisi için ‘${order.requiredPartName}’ talebi oluşturuldu.",
            type = "YENI_TALEP"
        )
        notificationDao.insertNotification(notification)
        firestoreSync.syncOrder(order.copy(id = insertedId))
        return insertedId
    }

    suspend fun markOrderPlaced(
        order: PartOrderRequest,
        supplier: String,
        refNumber: String,
        notes: String
    ): AppNotification {
        val updated = order.copy(
            status = OrderStatus.ORDERED,
            orderPlacedAt = System.currentTimeMillis(),
            orderSupplier = supplier.ifBlank { "Merkez Ana Depo / Tedarikçi" },
            orderRefNumber = refNumber.ifBlank { "SIP-${System.currentTimeMillis() % 100000}" },
            orderNotes = notes
        )
        partOrderDao.updateOrder(updated)
        firestoreSync.syncOrder(updated)

        val notificationMessage = "‘${order.customerName}’ adlı müşterinin siparişi oluşturuldu"
        val notification = AppNotification(
            orderId = order.id,
            customerName = order.customerName,
            technicianId = order.technicianId,
            title = "Sipariş Oluşturuldu",
            message = notificationMessage,
            type = "SIPARIS_GECILDI"
        )
        notificationDao.insertNotification(notification)

        NotificationHelper.showSystemNotification(
            context = context,
            notificationId = order.id.toInt(),
            title = "📦 Sipariş Geçildi",
            message = notificationMessage,
            orderId = order.id
        )

        return notification
    }

    suspend fun markOrderDelivered(
        order: PartOrderRequest,
        arrivedPhotoUri: String?,
        arrivalNotes: String
    ): AppNotification {
        val updated = order.copy(
            status = OrderStatus.DELIVERED,
            arrivedAt = System.currentTimeMillis(),
            arrivedPartPhotoUri = arrivedPhotoUri,
            arrivalNotes = arrivalNotes.ifBlank { "Parça merkez ofise ulaştı, montaja hazır." }
        )
        partOrderDao.updateOrder(updated)
        firestoreSync.syncOrder(updated)

        val notificationMessage = "‘${order.customerName}’ adlı müşterinin siparişi teslim edildi"
        val notification = AppNotification(
            orderId = order.id,
            customerName = order.customerName,
            technicianId = order.technicianId,
            title = "Parça Teslim Edildi",
            message = notificationMessage,
            type = "TESLIM_EDILDI"
        )
        notificationDao.insertNotification(notification)

        NotificationHelper.showSystemNotification(
            context = context,
            notificationId = (order.id + 10000).toInt(),
            title = "✅ Parça Teslim Edildi",
            message = notificationMessage,
            orderId = order.id
        )

        return notification
    }

    suspend fun updateStock(partId: Long, newQuantity: Int) {
        val part = sparePartDao.getPartById(partId)
        if (part != null) {
            val updated = part.copy(stockQuantity = newQuantity.coerceAtLeast(0), lastUpdated = System.currentTimeMillis())
            sparePartDao.updatePart(updated)
            firestoreSync.syncStock(updated)
        }
    }

    suspend fun addSparePart(part: SparePartItem) {
        val insertedId = sparePartDao.insertPart(part)
        firestoreSync.syncStock(part.copy(id = insertedId))
    }

    suspend fun markNotificationAsRead(id: Long) {
        notificationDao.markAsRead(id)
    }

    suspend fun markAllNotificationsAsRead() {
        notificationDao.markAllAsRead()
    }

    // --- Field Staff Management ---
    suspend fun addStaff(staff: com.example.data.model.FieldStaffMember): Long {
        return fieldStaffDao.insertStaff(staff)
    }

    suspend fun updateStaff(staff: com.example.data.model.FieldStaffMember) {
        fieldStaffDao.updateStaff(staff)
    }

    suspend fun deleteStaff(staffId: Long) {
        fieldStaffDao.deleteStaffById(staffId)
    }

    suspend fun findStaffByUsername(username: String): com.example.data.model.FieldStaffMember? {
        return fieldStaffDao.findStaffByUsername(username)
    }

    // --- Overdue Alert & 3-Day Snooze Logic ---
    suspend fun snoozeOrderNotification(orderId: Long, days: Int = 3): Boolean {
        val order = partOrderDao.getOrderByIdDirect(orderId) ?: return false
        val snoozePeriodMs = days * 24 * 3600 * 1000L
        val now = System.currentTimeMillis()
        val updated = order.copy(
            snoozedUntil = now + snoozePeriodMs,
            lastOverdueNotifiedAt = now
        )
        partOrderDao.updateOrder(updated)
        firestoreSync.syncOrder(updated)

        val notifMessage = "‘${order.customerName}’ adlı müşterinin geciken siparişi 3 gün süreyle ertelendi."
        val notification = AppNotification(
            orderId = order.id,
            customerName = order.customerName,
            technicianId = order.technicianId,
            title = "Bildirim Ertelendi (3 Gün)",
            message = notifMessage,
            type = "BILDIRIM_ERTELENDI"
        )
        notificationDao.insertNotification(notification)
        return true
    }

    suspend fun checkAndNotifyOverdueOrders(): List<PartOrderRequest> {
        val undelivered = partOrderDao.getUndeliveredOrders()
        val now = System.currentTimeMillis()
        val newlyNotified = mutableListOf<PartOrderRequest>()

        for (order in undelivered) {
            if (order.isOverdue && !order.isSnoozed) {
                // If never notified or overdue notification occurred more than 3 days ago (or snooze expired)
                val lastNotif = order.lastOverdueNotifiedAt ?: 0L
                val shouldNotify = (now - lastNotif) >= PartOrderRequest.THREE_DAYS_MS

                if (shouldNotify) {
                    val days = order.overdueDaysCount
                    val notifMessage = "‘${order.customerName}’ adlı müşterinin ‘${order.requiredPartName}’ siparişi $days gündür beklemede!"
                    val notification = AppNotification(
                        orderId = order.id,
                        customerName = order.customerName,
                        technicianId = order.technicianId,
                        title = "⚠️ 3 Günden Fazla Geciken Sipariş",
                        message = notifMessage,
                        type = "GECIKEN_SIPARIS"
                    )
                    notificationDao.insertNotification(notification)

                    NotificationHelper.showSystemNotification(
                        context = context,
                        notificationId = (order.id + 20000).toInt(),
                        title = "⚠️ Geciken Sipariş Uyarısı",
                        message = notifMessage,
                        orderId = order.id
                    )

                    val updatedOrder = order.copy(lastOverdueNotifiedAt = now)
                    partOrderDao.updateOrder(updatedOrder)
                    firestoreSync.syncOrder(updatedOrder)
                    newlyNotified.add(updatedOrder)
                }
            }
        }
        return newlyNotified
    }

    suspend fun seedSampleDataIfEmpty() {
        // Seed Stock if empty
        if (sparePartDao.getPartCount() == 0) {
            val initialParts = listOf(
                SparePartItem(
                    partCode = "VAI-0020020023",
                    partName = "Sirkülasyon Pompası",
                    category = "Kombi",
                    stockQuantity = 6,
                    minCriticalLevel = 3,
                    unitPrice = 1850.0,
                    locationShelf = "Raf B-04",
                    photoUri = "preset:pompa"
                ),
                SparePartItem(
                    partCode = "BSH-00705432",
                    partName = "İnvertör Kontrol Kartı (PCB)",
                    category = "Buzdolabı",
                    stockQuantity = 2, // Critical level
                    minCriticalLevel = 3,
                    unitPrice = 2400.0,
                    locationShelf = "Raf C-11",
                    photoUri = "preset:anakart"
                ),
                SparePartItem(
                    partCode = "MIT-E22D16100",
                    partName = "Step Kanat Motoru & Dış Fan",
                    category = "Klima",
                    stockQuantity = 8,
                    minCriticalLevel = 2,
                    unitPrice = 750.0,
                    locationShelf = "Raf D-02",
                    photoUri = "preset:step_motor"
                ),
                SparePartItem(
                    partCode = "ECA-3WAY-99",
                    partName = "3 Yollu Vana & Ventil Gövdesi",
                    category = "Kombi",
                    stockQuantity = 1, // Critical level
                    minCriticalLevel = 3,
                    unitPrice = 1150.0,
                    locationShelf = "Raf B-09",
                    photoUri = "preset:ventil"
                ),
                SparePartItem(
                    partCode = "ARC-FAN-441",
                    partName = "No-Frost İç Evaporatör Fanı",
                    category = "Buzdolabı",
                    stockQuantity = 0, // Out of stock
                    minCriticalLevel = 2,
                    unitPrice = 620.0,
                    locationShelf = "Raf C-05",
                    photoUri = "preset:buzdolabi"
                ),
                SparePartItem(
                    partCode = "DAI-EXP-2022",
                    partName = "Elektronik Genleşme Valfi",
                    category = "Klima",
                    stockQuantity = 5,
                    minCriticalLevel = 2,
                    unitPrice = 1450.0,
                    locationShelf = "Raf D-14",
                    photoUri = "preset:klima"
                )
            )
            sparePartDao.insertParts(initialParts)
        }

        // Clean up any legacy mock staff or mock orders so ONLY user-added accounts exist
        try {
            for (u in listOf("ahmet.usta", "mehmet.teknik", "can.servis", "tech_01", "tech_02", "tech_03")) {
                val found = fieldStaffDao.findStaffByUsername(u)
                if (found != null) {
                    fieldStaffDao.deleteStaff(found)
                }
            }
        } catch (_: Exception) {}
    }
}
