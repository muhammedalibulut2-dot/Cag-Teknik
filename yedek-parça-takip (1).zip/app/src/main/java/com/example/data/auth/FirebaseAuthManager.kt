package com.example.data.auth

import android.app.Activity
import android.content.Context
import android.util.Log
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.GetCredentialCancellationException
import com.example.R
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.google.android.libraries.identity.googleid.GetSignInWithGoogleOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class FirebaseAuthManager(private val context: Context) {
    private val auth: FirebaseAuth = Firebase.auth
    private val credentialManager = CredentialManager.create(context)

    private val _currentUser = MutableStateFlow<FirebaseUser?>(auth.currentUser)
    val currentUser: StateFlow<FirebaseUser?> = _currentUser.asStateFlow()

    private val authListener = FirebaseAuth.AuthStateListener { firebaseAuth ->
        _currentUser.value = firebaseAuth.currentUser
    }

    init {
        auth.addAuthStateListener(authListener)
    }

    fun getWebClientId(): String? {
        return try {
            context.getString(R.string.default_web_client_id)
        } catch (e: Exception) {
            Log.w("FirebaseAuthManager", "default_web_client_id not found: ${e.message}")
            null
        }
    }

    fun signInWithGoogle(
        activity: Activity,
        targetRole: UserRole,
        scope: CoroutineScope,
        onSuccess: (UserAccount) -> Unit,
        onError: (String) -> Unit,
        onCancelled: () -> Unit
    ) {
        val clientId = getWebClientId()
        if (clientId.isNullOrBlank()) {
            onError("Google Sign-In yapılandırması eksik (default_web_client_id bulunamadı).")
            return
        }

        val signInOption = GetSignInWithGoogleOption.Builder(serverClientId = clientId).build()
        val request = GetCredentialRequest.Builder().addCredentialOption(signInOption).build()

        scope.launch {
            try {
                val result = credentialManager.getCredential(activity, request)
                val credential = result.credential
                if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
                    val googleIdToken = GoogleIdTokenCredential.createFrom(credential.data).idToken
                    val authCredential = GoogleAuthProvider.getCredential(googleIdToken, null)
                    val authResult = auth.signInWithCredential(authCredential).await()
                    val user = authResult.user

                    if (user != null) {
                        val account = UserAccount(
                            username = user.email ?: user.uid,
                            passwordHash = "",
                            fullName = user.displayName ?: if (targetRole == UserRole.HEADQUARTERS) "Merkez Ofis Yetkilisi" else "Saha Teknisyeni",
                            role = targetRole,
                            technicianId = if (targetRole == UserRole.TECHNICIAN) "tech_${user.uid.take(6)}" else null,
                            phone = user.phoneNumber ?: ""
                        )
                        saveUserRoleToFirestore(user.uid, account)
                        onSuccess(account)
                    } else {
                        onError("Kullanıcı bilgisi alınamadı.")
                    }
                } else {
                    onError("Beklenmeyen kimlik doğrulama yanıtı alındı.")
                }
            } catch (e: GetCredentialCancellationException) {
                Log.w("FirebaseAuthManager", "Google Sign-In iptal edildi: ${e.message}")
                onCancelled()
            } catch (e: Exception) {
                Log.e("FirebaseAuthManager", "Google Sign-In hatası", e)
                onError(e.localizedMessage ?: "Giriş işlemi başarısız oldu.")
            }
        }
    }

    private fun saveUserRoleToFirestore(uid: String, account: UserAccount) {
        try {
            val dbId = context.getString(R.string.firestore_database_id)
            val db = if (dbId.isNotBlank()) FirebaseFirestore.getInstance(dbId) else FirebaseFirestore.getInstance()
            val userMap = hashMapOf(
                "uid" to uid,
                "email" to account.username,
                "fullName" to account.fullName,
                "role" to account.role.name,
                "technicianId" to (account.technicianId ?: ""),
                "lastLogin" to System.currentTimeMillis()
            )
            db.collection("users").document(uid).set(userMap)
        } catch (e: Exception) {
            Log.w("FirebaseAuthManager", "Kullanıcı rolü Firestore'a kaydedilemedi: ${e.message}")
        }
    }

    fun signOut(scope: CoroutineScope, onComplete: () -> Unit) {
        auth.signOut()
        scope.launch {
            try {
                credentialManager.clearCredentialState(ClearCredentialStateRequest())
            } catch (e: Exception) {
                Log.e("FirebaseAuthManager", "Kimlik bilgisi temizlenemedi", e)
            } finally {
                onComplete()
            }
        }
    }
}
