package com.example.data.model

enum class UserRole(val displayName: String, val roleSubtitle: String) {
    TECHNICIAN("Saha Personeli", "Mobil Cihaz & Arıza Kaydı"),
    HEADQUARTERS("Ana Hesap (Merkez)", "Sipariş & Teslimat Yönetimi")
}

object OrderStatus {
    const val PENDING = "BEKLEMEDE"
    const val APPROVED = "ONAYLANDI"
    const val ORDERED = "SIPARIS_GECILDI"
    const val DELIVERED = "TESLIM_EDILDI"

    fun getLabel(status: String): String = when (status) {
        PENDING -> "Beklemede (Onay Bekliyor)"
        APPROVED -> "Merkez Onayladı"
        ORDERED -> "Sipariş Geçildi"
        DELIVERED -> "Parça Geldi / Teslim Edildi"
        else -> status
    }
}
