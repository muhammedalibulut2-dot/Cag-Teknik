package com.example.data.local

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.example.data.model.PartOrderRequest
import kotlinx.coroutines.flow.Flow

@Dao
interface PartOrderDao {
    @Query("SELECT * FROM part_order_requests ORDER BY createdAt DESC")
    fun getAllOrders(): Flow<List<PartOrderRequest>>

    @Query("SELECT * FROM part_order_requests WHERE id = :id")
    fun getOrderById(id: Long): Flow<PartOrderRequest?>

    @Query("SELECT * FROM part_order_requests WHERE id = :id")
    suspend fun getOrderByIdDirect(id: Long): PartOrderRequest?

    @Query("SELECT * FROM part_order_requests WHERE status != 'DELIVERED'")
    suspend fun getUndeliveredOrders(): List<PartOrderRequest>

    @Query("SELECT * FROM part_order_requests WHERE status = :status ORDER BY createdAt DESC")
    fun getOrdersByStatus(status: String): Flow<List<PartOrderRequest>>

    @Query("SELECT * FROM part_order_requests WHERE technicianId = :techId ORDER BY createdAt DESC")
    fun getOrdersByTechnician(techId: String): Flow<List<PartOrderRequest>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrder(order: PartOrderRequest): Long

    @Update
    suspend fun updateOrder(order: PartOrderRequest)

    @Delete
    suspend fun deleteOrder(order: PartOrderRequest)

    @Query("SELECT COUNT(*) FROM part_order_requests")
    suspend fun getOrderCount(): Int
}
