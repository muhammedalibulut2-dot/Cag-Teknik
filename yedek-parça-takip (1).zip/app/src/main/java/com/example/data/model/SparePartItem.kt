package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "spare_parts_inventory")
data class SparePartItem(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val partCode: String,
    val partName: String,
    val category: String,
    val stockQuantity: Int,
    val minCriticalLevel: Int = 3,
    val unitPrice: Double = 0.0,
    val locationShelf: String = "Merkez Depo A-1",
    val photoUri: String? = null,
    val lastUpdated: Long = System.currentTimeMillis()
) {
    val isCritical: Boolean
        get() = stockQuantity in 1..minCriticalLevel

    val isOutOfStock: Boolean
        get() = stockQuantity <= 0
}
