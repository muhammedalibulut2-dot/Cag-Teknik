package com.example.data.local

import android.content.Context
import android.content.SharedPreferences
import com.example.data.model.PredefinedAccounts
import com.example.data.model.UserAccount
import com.example.data.model.UserRole

class SessionManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("app_session_prefs", Context.MODE_PRIVATE)

    companion object {
        private const val KEY_IS_LOGGED_IN = "is_logged_in"
        private const val KEY_REMEMBER_ME = "remember_me"
        private const val KEY_USERNAME = "username"
        private const val KEY_FULL_NAME = "full_name"
        private const val KEY_ROLE = "role"
        private const val KEY_TECH_ID = "tech_id"
    }

    fun saveUserSession(account: UserAccount, rememberMe: Boolean = false) {
        prefs.edit()
            .putBoolean(KEY_IS_LOGGED_IN, true)
            .putBoolean(KEY_REMEMBER_ME, rememberMe)
            .putString(KEY_USERNAME, account.username)
            .putString(KEY_FULL_NAME, account.fullName)
            .putString(KEY_ROLE, account.role.name)
            .putString(KEY_TECH_ID, account.technicianId)
            .apply()
    }

    fun getSavedUser(): UserAccount? {
        val isLoggedIn = prefs.getBoolean(KEY_IS_LOGGED_IN, false)
        val rememberMe = prefs.getBoolean(KEY_REMEMBER_ME, false)
        // If 'rememberMe' is false or user is not logged in, require entering credentials!
        if (!isLoggedIn || !rememberMe) return null

        val username = prefs.getString(KEY_USERNAME, null) ?: return null
        val fullName = prefs.getString(KEY_FULL_NAME, "Kullanıcı") ?: "Kullanıcı"
        val roleStr = prefs.getString(KEY_ROLE, UserRole.TECHNICIAN.name) ?: UserRole.TECHNICIAN.name
        val techId = prefs.getString(KEY_TECH_ID, null)

        val role = try {
            UserRole.valueOf(roleStr)
        } catch (_: Exception) {
            UserRole.TECHNICIAN
        }

        return UserAccount(
            username = username,
            passwordHash = "",
            fullName = fullName,
            role = role,
            technicianId = techId
        )
    }

    fun getLastUsername(): String? {
        return prefs.getString(KEY_USERNAME, null)
    }

    fun clearSession() {
        val lastUser = prefs.getString(KEY_USERNAME, null)
        prefs.edit().clear().apply()
        if (lastUser != null) {
            prefs.edit().putString(KEY_USERNAME, lastUser).apply()
        }
    }
}
