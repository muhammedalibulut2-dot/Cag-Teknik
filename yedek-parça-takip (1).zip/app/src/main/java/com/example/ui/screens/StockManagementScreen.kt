package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.SparePartItem
import com.example.ui.components.TechnicalPhotoThumbnail
import com.example.ui.viewmodel.MainViewModel

import androidx.compose.material.icons.filled.QrCodeScanner
import com.example.ui.components.BarcodeScannerDialog

@Composable
fun StockManagementScreen(viewModel: MainViewModel) {
    val stockItems by viewModel.allStock.collectAsStateWithLifecycle()
    val criticalItems by viewModel.criticalStock.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var showAddPartDialog by remember { mutableStateOf(false) }
    var showBarcodeScanner by remember { mutableStateOf(false) }
    var lastScannedInfo by remember { mutableStateOf<String?>(null) }

    val filteredList = stockItems.filter { item ->
        searchQuery.isBlank() ||
                item.partName.contains(searchQuery, ignoreCase = true) ||
                item.partCode.contains(searchQuery, ignoreCase = true) ||
                item.category.contains(searchQuery, ignoreCase = true)
    }

    val totalPieces = stockItems.sumOf { it.stockQuantity }
    val outOfStockCount = stockItems.count { it.stockQuantity == 0 }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddPartDialog = true },
                containerColor = MaterialTheme.colorScheme.primary,
                contentColor = Color.White,
                modifier = Modifier.testTag("add_new_part_fab")
            ) {
                Icon(Icons.Default.Add, contentDescription = "Yeni Parça Ekle")
            }
        },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            item {
                Spacer(modifier = Modifier.height(6.dp))

                // Stock Metrics Overview Cards
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    MetricBox(
                        title = "Toplam Çeşit",
                        value = "${stockItems.size}",
                        icon = Icons.Default.Inventory,
                        bgColor = Color(0xFFDBEAFE),
                        textColor = Color(0xFF1E40AF),
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Stok Adedi",
                        value = "$totalPieces",
                        icon = Icons.Default.CheckCircle,
                        bgColor = Color(0xFFD1FAE5),
                        textColor = Color(0xFF065F46),
                        modifier = Modifier.weight(1f)
                    )
                    MetricBox(
                        title = "Kritik Stok",
                        value = "${criticalItems.size}",
                        icon = Icons.Default.Warning,
                        bgColor = Color(0xFFFEF3C7),
                        textColor = Color(0xFF92400E),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // Critical Stock Alert Banner
            if (criticalItems.isNotEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                        border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFFEF4444)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("critical_stock_alert_card")
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    Icons.Default.Error,
                                    contentDescription = null,
                                    tint = Color(0xFFDC2626),
                                    modifier = Modifier.size(22.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "DİKKAT: ${criticalItems.size} Parça Kritik Seviyede!",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp,
                                    color = Color(0xFFB91C1C)
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "Aşağıdaki parçalar minimum kritik eşiğin altına düşmüştür. Saha taleplerinin aksamaması için tedarikçi siparişi geçilmelidir.",
                                fontSize = 12.sp,
                                color = Color(0xFF7F1D1D),
                                lineHeight = 16.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                criticalItems.take(3).forEach { item ->
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = Color(0xFFFEE2E2)
                                    ) {
                                        Text(
                                            text = "${item.partName}: ${item.stockQuantity} adet",
                                            fontSize = 11.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = Color(0xFFB91C1C),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Search Bar & Barcode Scanner Integration
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = searchQuery,
                            onValueChange = {
                                searchQuery = it
                                if (lastScannedInfo != null) lastScannedInfo = null
                            },
                            placeholder = { Text("Parça adı, OEM kodu ara...") },
                            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                            trailingIcon = {
                                if (searchQuery.isNotBlank()) {
                                    IconButton(onClick = {
                                        searchQuery = ""
                                        lastScannedInfo = null
                                    }) {
                                        Icon(Icons.Default.Close, contentDescription = "Temizle")
                                    }
                                }
                            },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .testTag("stock_search_input"),
                            singleLine = true
                        )

                        Spacer(modifier = Modifier.width(8.dp))

                        Button(
                            onClick = { showBarcodeScanner = true },
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .height(56.dp)
                                .testTag("scan_barcode_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = "Barkod Tara",
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Barkod",
                                fontWeight = FontWeight.Bold,
                                fontSize = 13.sp
                            )
                        }
                    }

                    // Scanned feedback banner if any
                    if (lastScannedInfo != null) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("scanned_barcode_info_banner")
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = lastScannedInfo.orEmpty(),
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onTertiaryContainer,
                                    modifier = Modifier.weight(1f)
                                )
                                IconButton(
                                    onClick = { lastScannedInfo = null },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(
                                        Icons.Default.Close,
                                        contentDescription = "Kapat",
                                        tint = MaterialTheme.colorScheme.onTertiaryContainer,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // Stock Items List
            items(filteredList, key = { it.id }) { item ->
                StockItemCard(
                    item = item,
                    onIncrement = { viewModel.updatePartStock(item.id, item.stockQuantity + 1) },
                    onDecrement = { viewModel.updatePartStock(item.id, (item.stockQuantity - 1).coerceAtLeast(0)) }
                )
            }

            item {
                Spacer(modifier = Modifier.height(80.dp))
            }
        }

        // Add New Part Modal
        if (showAddPartDialog) {
            AddSparePartModal(
                onDismiss = { showAddPartDialog = false },
                onAddPart = { code, name, category, qty, critical, price, shelf ->
                    viewModel.addNewPart(code, name, category, qty, critical, price, shelf)
                    showAddPartDialog = false
                }
            )
        }

        // Camera Barcode Scanner Modal
        if (showBarcodeScanner) {
            BarcodeScannerDialog(
                onDismiss = { showBarcodeScanner = false },
                onBarcodeScanned = { scannedCode ->
                    searchQuery = scannedCode
                    val matched = stockItems.find {
                        it.partCode.equals(scannedCode, ignoreCase = true) ||
                        it.partCode.contains(scannedCode, ignoreCase = true)
                    }
                    if (matched != null) {
                        lastScannedInfo = "✅ Barkod Okundu: ${matched.partName} (OEM: ${matched.partCode}, Stok: ${matched.stockQuantity} Adet, Konum: ${matched.locationShelf})"
                    } else {
                        lastScannedInfo = "🔍 Barkod: '$scannedCode' - Stokta bulunamadı. Yeni parça ekleyebilirsiniz."
                    }
                }
            )
        }
    }
}

@Composable
fun StockItemCard(
    item: SparePartItem,
    onIncrement: () -> Unit,
    onDecrement: () -> Unit
) {
    ElevatedCard(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.elevatedCardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.elevatedCardElevation(defaultElevation = 2.dp),
        modifier = Modifier
            .fillMaxWidth()
            .testTag("stock_item_${item.id}")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = item.partName,
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                    Text(
                        text = "Kod: ${item.partCode} • ${item.category}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "Konum: ${item.locationShelf}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Stock Badge
                val (badgeBg, badgeText, label) = when {
                    item.stockQuantity <= 0 -> Triple(Color(0xFFFEE2E2), Color(0xFFDC2626), "TÜKENDİ")
                    item.stockQuantity <= item.minCriticalLevel -> Triple(Color(0xFFFEF3C7), Color(0xFFB45309), "KRİTİK (${item.stockQuantity})")
                    else -> Triple(Color(0xFFD1FAE5), Color(0xFF047857), "STOKTA (${item.stockQuantity})")
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = badgeBg
                ) {
                    Text(
                        text = label,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = badgeText,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Stock Count Adjustment Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "Mevcut Miktar: ",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "${item.stockQuantity} Adet",
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (item.stockQuantity <= item.minCriticalLevel) Color(0xFFDC2626) else MaterialTheme.colorScheme.primary
                    )
                }

                // Stepper Buttons
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    FilledTonalButton(
                        onClick = onDecrement,
                        enabled = item.stockQuantity > 0,
                        shape = CircleShape,
                        modifier = Modifier.size(34.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Remove, contentDescription = "Eksilt", modifier = Modifier.size(16.dp))
                    }

                    Text(
                        text = "${item.stockQuantity}",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp,
                        modifier = Modifier.padding(horizontal = 6.dp)
                    )

                    FilledTonalButton(
                        onClick = onIncrement,
                        shape = CircleShape,
                        modifier = Modifier.size(34.dp),
                        contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Artır", modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
fun MetricBox(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    bgColor: Color,
    textColor: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = bgColor,
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = null,
                tint = textColor,
                modifier = Modifier.size(20.dp)
            )
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = value,
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                color = textColor
            )
            Text(
                text = title,
                fontSize = 10.sp,
                fontWeight = FontWeight.SemiBold,
                color = textColor
            )
        }
    }
}

@Composable
fun AddSparePartModal(
    onDismiss: () -> Unit,
    onAddPart: (code: String, name: String, category: String, qty: Int, critical: Int, price: Double, shelf: String) -> Unit
) {
    var code by remember { mutableStateOf("") }
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("Kombi") }
    var quantityStr by remember { mutableStateOf("10") }
    var criticalStr by remember { mutableStateOf("3") }
    var shelf by remember { mutableStateOf("Merkez Depo Raf A-1") }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "Yeni Yedek Parça Ekle",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    IconButton(onClick = onDismiss, modifier = Modifier.size(28.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("Parça Adı *") },
                    placeholder = { Text("Örn: Sirkülasyon Pompası") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = code,
                    onValueChange = { code = it },
                    label = { Text("OEM / Parça Kodu *") },
                    placeholder = { Text("Örn: VAI-002002") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("Kategori (Kombi, Klima, Buzdolabı vb.)") },
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityStr,
                        onValueChange = { quantityStr = it },
                        label = { Text("Başlangıç Stok") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = criticalStr,
                        onValueChange = { criticalStr = it },
                        label = { Text("Kritik Eşik") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = shelf,
                    onValueChange = { shelf = it },
                    label = { Text("Depo Raf / Bölüm") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(18.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    OutlinedButton(onClick = onDismiss) {
                        Text("İptal")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = {
                            if (name.isNotBlank() && code.isNotBlank()) {
                                onAddPart(
                                    code,
                                    name,
                                    category,
                                    quantityStr.toIntOrNull() ?: 1,
                                    criticalStr.toIntOrNull() ?: 3,
                                    0.0,
                                    shelf
                                )
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("Parçayı Kaydet")
                    }
                }
            }
        }
    }
}
