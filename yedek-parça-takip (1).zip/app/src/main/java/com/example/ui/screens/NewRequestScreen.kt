package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.horizontalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DevicesOther
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.HomeRepairService
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.TextButton
import com.example.ui.components.BarcodeScannerDialog
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.PhotoPickerModal
import com.example.ui.components.TechnicalPhotoThumbnail
import com.example.ui.viewmodel.MainViewModel
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NewRequestScreen(
    viewModel: MainViewModel,
    onSuccessNav: () -> Unit
) {
    val scope = rememberCoroutineScope()
    val snackbarHostState = remember { SnackbarHostState() }
    val allStock by viewModel.allStock.collectAsStateWithLifecycle()

    // Form fields
    var customerName by remember { mutableStateOf("") }
    var customerPhone by remember { mutableStateOf("") }
    var customerAddress by remember { mutableStateOf("") }

    val commonDeviceTypes = listOf("Kombi", "Buzdolabı", "Klima", "Çamaşır Mak.", "Endüstriyel Cihaz")
    var selectedDeviceType by remember { mutableStateOf("Kombi") }
    var deviceModel by remember { mutableStateOf("") }
    var deviceSerial by remember { mutableStateOf("") }
    var faultDescription by remember { mutableStateOf("") }
    var devicePhotoUri by remember { mutableStateOf<String?>(null) }

    var requiredPartName by remember { mutableStateOf("") }
    var requiredPartCode by remember { mutableStateOf("") }
    var requiredPartDescription by remember { mutableStateOf("") }
    var requiredPartPhotoUri by remember { mutableStateOf<String?>(null) }
    var deductFromStock by remember { mutableStateOf(false) }
    var partQuantity by remember { mutableIntStateOf(1) }

    // Photo picker modal states
    var showDevicePhotoPicker by remember { mutableStateOf(false) }
    var showPartPhotoPicker by remember { mutableStateOf(false) }
    var showBarcodeScanner by remember { mutableStateOf(false) }

    // Validation
    var nameError by remember { mutableStateOf(false) }
    var partError by remember { mutableStateOf(false) }

    val context = androidx.compose.ui.platform.LocalContext.current
    val syncManager = remember { com.example.data.firebase.FirestoreSyncManager(context) }
    var isDeviceOnline by remember { mutableStateOf(syncManager.isOnline()) }

    // Technician configuration
    val loggedInUser by viewModel.loggedInUser.collectAsStateWithLifecycle()
    val syncedUsers by viewModel.syncedServerUsers.collectAsStateWithLifecycle()
    var technicianNameInput by remember(loggedInUser) {
        mutableStateOf(loggedInUser?.fullName ?: "Saha Teknisyeni")
    }
    var technicianIdInput by remember(loggedInUser) {
        mutableStateOf(loggedInUser?.technicianId ?: (loggedInUser?.username ?: "tech_user"))
    }
    var showTechEditDialog by remember { mutableStateOf(false) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = MaterialTheme.colorScheme.background
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(horizontal = 16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            if (!isDeviceOnline) {
                Surface(
                    color = MaterialTheme.colorScheme.errorContainer,
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onErrorContainer,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "İnternet bağlantısı yok! Siparişiniz telefonda saklanacak, internet açıldığında otomatik merkeze iletilecektir.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onErrorContainer,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Header Banner
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.HomeRepairService,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                        modifier = Modifier.padding(end = 12.dp)
                    )
                    Column {
                        Text(
                            text = "Yeni Saha Arıza & Parça Kaydı",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                        Text(
                            text = "Müşteri ve arızalı cihaz bilgilerini girin, parça fotoğrafı ekleyerek talebi anlık olarak merkeze iletin.",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }
                }
            }

            // Saha Teknisyeni Ayarı & Seçimi
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Engineering,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary,
                                modifier = Modifier.size(24.dp)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "Talep Eden Saha Teknisyeni:",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    text = technicianNameInput,
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                        }

                        TextButton(
                            onClick = { showTechEditDialog = true },
                            modifier = Modifier.testTag("change_technician_btn")
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Değiştir", fontSize = 12.sp)
                        }
                    }

                    val registeredTechs = syncedUsers.map { Pair(it.fullName, it.technicianId ?: it.username) }
                    if (registeredTechs.isNotEmpty()) {
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "Kayıtlı Teknisyenler:",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(
                            modifier = Modifier.horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            registeredTechs.forEach { (name, id) ->
                                val isSelected = technicianNameInput == name
                                FilterChip(
                                    selected = isSelected,
                                    onClick = {
                                        technicianNameInput = name
                                        technicianIdInput = id
                                        viewModel.setCustomTechnician(name, id)
                                    },
                                    label = { Text(name, fontSize = 11.sp) },
                                    leadingIcon = if (isSelected) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                    } else null
                                )
                            }
                        }
                    }
                }
            }

            // 1. Müşteri Bilgileri
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.Person,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "1. Müşteri Bilgileri",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = customerName,
                        onValueChange = {
                            customerName = it
                            if (it.isNotBlank()) nameError = false
                        },
                        label = { Text("Müşteri Adı Soyadı *") },
                        isError = nameError,
                        supportingText = if (nameError) { { Text("Müşteri adı zorunludur") } } else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_customer_name")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = customerPhone,
                        onValueChange = { customerPhone = it },
                        label = { Text("İletişim Numarası") },
                        placeholder = { Text("05XX XXX XX XX") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_customer_phone")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = customerAddress,
                        onValueChange = { customerAddress = it },
                        label = { Text("Müşteri Adresi / Mahalle / İlçe") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_customer_address"),
                        maxLines = 2
                    )
                }
            }

            // 2. Cihaz & Arıza Bilgileri
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            Icons.Default.DevicesOther,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.primary
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "2. Cihaz & Arıza Tanımı",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Cihaz Türü:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        commonDeviceTypes.take(3).forEach { type ->
                            FilterChip(
                                selected = selectedDeviceType == type,
                                onClick = { selectedDeviceType = type },
                                label = { Text(type, fontSize = 12.sp) }
                            )
                        }
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        commonDeviceTypes.drop(3).forEach { type ->
                            FilterChip(
                                selected = selectedDeviceType == type,
                                onClick = { selectedDeviceType = type },
                                label = { Text(type, fontSize = 12.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = deviceModel,
                        onValueChange = { deviceModel = it },
                        label = { Text("Marka & Model") },
                        placeholder = { Text("Örn: Vaillant ecoTEC / Bosch Serie 6") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_device_model")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = deviceSerial,
                        onValueChange = { deviceSerial = it },
                        label = { Text("Cihaz Seri Numarası (Varsa)") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = faultDescription,
                        onValueChange = { faultDescription = it },
                        label = { Text("Arıza Belirtisi & Açıklama") },
                        placeholder = { Text("Örn: Cihaz alev almıyor, sirkülasyon durmuş.") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_fault_description"),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Cihaz & Arıza Görseli:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    TechnicalPhotoThumbnail(
                        photoUri = devicePhotoUri,
                        modifier = Modifier.fillMaxWidth(),
                        height = 120.dp,
                        label = "Cihaz Görseli",
                        onClick = { showDevicePhotoPicker = true }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { showDevicePhotoPicker = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (devicePhotoUri == null) "Cihaz Fotoğrafı Ekle" else "Cihaz Fotoğrafını Değiştir")
                    }
                }
            }

            // 3. Gerekli Yedek Parça & Canlı Stok Durumu
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    MaterialTheme.colorScheme.primary.copy(alpha = 0.3f)
                ),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                Icons.Default.Build,
                                contentDescription = null,
                                tint = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "3. Gerekli Yedek Parça",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Quick Select from Stock Catalog
                    Text(
                        text = "Depodaki Hazır Parçalardan Hızlı Seç:",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(allStock.take(5)) { stockItem ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                modifier = Modifier
                                    .clickable {
                                        requiredPartName = stockItem.partName
                                        requiredPartCode = stockItem.partCode
                                        requiredPartDescription = "${stockItem.category} - ${stockItem.locationShelf}"
                                        partError = false
                                    }
                                    .padding(vertical = 2.dp)
                            ) {
                                Text(
                                    text = "${stockItem.partName} (${stockItem.stockQuantity})",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = requiredPartName,
                        onValueChange = {
                            requiredPartName = it
                            if (it.isNotBlank()) partError = false
                        },
                        label = { Text("Gerekli Parçanın Adı *") },
                        placeholder = { Text("Örn: Sirkülasyon Pompası, İnvertör Kartı") },
                        isError = partError,
                        supportingText = if (partError) { { Text("Parça adı zorunludur") } } else null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_required_part_name")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = requiredPartCode,
                        onValueChange = { requiredPartCode = it },
                        label = { Text("Parça Kodu / OEM / Barkod") },
                        placeholder = { Text("Örn: VAI-0020020023") },
                        trailingIcon = {
                            IconButton(
                                onClick = { showBarcodeScanner = true },
                                modifier = Modifier.testTag("scan_part_barcode_btn")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = "Barkod Tara",
                                    tint = MaterialTheme.colorScheme.primary
                                )
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_required_part_code")
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    // Parça Miktarı Seçimi
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Talep Edilen Parça Adedi:",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                FilledTonalButton(
                                    onClick = { if (partQuantity > 1) partQuantity-- },
                                    shape = CircleShape,
                                    modifier = Modifier.size(32.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.Remove, contentDescription = "Azalt", modifier = Modifier.size(16.dp))
                                }
                                Text(
                                    text = "$partQuantity",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 16.sp,
                                    modifier = Modifier.padding(horizontal = 14.dp)
                                )
                                FilledTonalButton(
                                    onClick = { partQuantity++ },
                                    shape = CircleShape,
                                    modifier = Modifier.size(32.dp),
                                    contentPadding = androidx.compose.foundation.layout.PaddingValues(0.dp)
                                ) {
                                    Icon(Icons.Default.Add, contentDescription = "Artır", modifier = Modifier.size(16.dp))
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = requiredPartDescription,
                        onValueChange = { requiredPartDescription = it },
                        label = { Text("Parça Notları / Montaj Detayı") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 2
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Text(
                        text = "Gerekli Parça Görseli:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    TechnicalPhotoThumbnail(
                        photoUri = requiredPartPhotoUri,
                        modifier = Modifier.fillMaxWidth(),
                        height = 130.dp,
                        label = "Gerekli Parça Görseli",
                        onClick = { showPartPhotoPicker = true }
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedButton(
                        onClick = { showPartPhotoPicker = true },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (requiredPartPhotoUri == null) "Gerekli Parça Fotoğrafı Ekle" else "Parça Fotoğrafını Değiştir")
                    }
                }
            }

            // Submit Button
            Button(
                onClick = {
                    var hasError = false
                    if (customerName.isBlank()) {
                        nameError = true
                        hasError = true
                    }
                    if (requiredPartName.isBlank()) {
                        partError = true
                        hasError = true
                    }
                    if (hasError) {
                        scope.launch {
                            snackbarHostState.showSnackbar("Lütfen zorunlu alanları (Müşteri Adı ve Parça Adı) doldurunuz.")
                        }
                        return@Button
                    }

                    viewModel.createRequest(
                        customerName = customerName,
                        customerPhone = customerPhone.ifBlank { "0500 000 00 00" },
                        customerAddress = customerAddress.ifBlank { "Merkez Mah." },
                        deviceType = selectedDeviceType,
                        deviceModel = deviceModel.ifBlank { "Standart Model" },
                        deviceSerial = deviceSerial,
                        faultDescription = faultDescription.ifBlank { "Teknisyen incelemesi yapıldı, parça değişimi gerekiyor." },
                        devicePhotoUri = devicePhotoUri,
                        requiredPartName = requiredPartName,
                        requiredPartCode = requiredPartCode,
                        requiredPartDescription = requiredPartDescription,
                        requiredPartPhotoUri = requiredPartPhotoUri,
                        isStockDeducted = deductFromStock,
                        partQuantity = partQuantity,
                        technicianName = technicianNameInput,
                        technicianId = technicianIdInput,
                        onSuccess = {
                            onSuccessNav()
                        }
                    )
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("submit_request_button"),
                colors = ButtonDefaults.buttonColors(
                    containerColor = MaterialTheme.colorScheme.primary
                )
            ) {
                Icon(Icons.Default.Send, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "Talebi Merkeze İlet",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            Spacer(modifier = Modifier.height(24.dp))
        }

        // Photo pickers
        if (showDevicePhotoPicker) {
            PhotoPickerModal(
                title = "Cihaz & Arıza Görseli Seç",
                onDismiss = { showDevicePhotoPicker = false },
                onPhotoSelected = { uri -> devicePhotoUri = uri }
            )
        }

        if (showPartPhotoPicker) {
            PhotoPickerModal(
                title = "Gerekli Parça Görseli Seç",
                onDismiss = { showPartPhotoPicker = false },
                onPhotoSelected = { uri -> requiredPartPhotoUri = uri }
            )
        }

        if (showBarcodeScanner) {
            BarcodeScannerDialog(
                onDismiss = { showBarcodeScanner = false },
                onBarcodeScanned = { scannedCode ->
                    requiredPartCode = scannedCode
                    val matched = allStock.find {
                        it.partCode.equals(scannedCode, ignoreCase = true) ||
                        it.partCode.contains(scannedCode, ignoreCase = true)
                    }
                    if (matched != null) {
                        requiredPartName = matched.partName
                        requiredPartDescription = "${matched.category} - ${matched.locationShelf}"
                        partError = false
                    }
                }
            )
        }

        if (showTechEditDialog) {
            var tempName by remember { mutableStateOf(technicianNameInput) }
            AlertDialog(
                onDismissRequest = { showTechEditDialog = false },
                title = { Text("Teknisyen Bilgisini Ayarla") },
                text = {
                    Column {
                        Text("Siparişlerinizde görünecek teknisyen adı ve soyadını giriniz:", fontSize = 13.sp)
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = tempName,
                            onValueChange = { tempName = it },
                            label = { Text("Teknisyen Adı Soyadı") },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("custom_tech_name_input")
                        )
                    }
                },
                confirmButton = {
                    Button(
                        onClick = {
                            if (tempName.isNotBlank()) {
                                technicianNameInput = tempName.trim()
                                technicianIdInput = "tech_${tempName.trim().lowercase().replace(" ", "_")}"
                                viewModel.setCustomTechnician(technicianNameInput, technicianIdInput)
                            }
                            showTechEditDialog = false
                        }
                    ) {
                        Text("Kaydet")
                    }
                },
                dismissButton = {
                    TextButton(onClick = { showTechEditDialog = false }) {
                        Text("İptal")
                    }
                }
            )
        }
    }
}
