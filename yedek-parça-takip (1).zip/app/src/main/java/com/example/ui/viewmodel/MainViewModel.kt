package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.SessionManager
import com.example.data.model.AppNotification
import com.example.data.model.OrderStatus
import com.example.data.model.PartOrderRequest
import com.example.data.model.PredefinedAccounts
import com.example.data.model.SparePartItem
import com.example.data.model.UserAccount
import com.example.data.model.UserRole
import com.example.data.repository.PartOrderRepository
import com.example.data.repository.TechnicianPerformance
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MainViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = PartOrderRepository(application)
    private val sessionManager = SessionManager(application)
    val firebaseAuthManager = com.example.data.auth.FirebaseAuthManager(application)

    // User Authentication State
    private val _loggedInUser = MutableStateFlow<UserAccount?>(null)
    val loggedInUser: StateFlow<UserAccount?> = _loggedInUser.asStateFlow()

    val currentRole: StateFlow<UserRole> = combine(_loggedInUser) { userArr ->
        userArr[0]?.role ?: UserRole.TECHNICIAN
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = UserRole.TECHNICIAN
    )

    // Active technician info based on login
    val activeTechnicianName: String
        get() = _loggedInUser.value?.fullName ?: "Saha Teknisyeni"

    val activeTechnicianId: String
        get() = _loggedInUser.value?.technicianId ?: (_loggedInUser.value?.username ?: "tech_user")

    // Search and filter state for headquarters table view
    val searchQuery = MutableStateFlow("")
    val statusFilter = MutableStateFlow<String?>(null) // null = Tümü
    val dateFilter = MutableStateFlow("ALL") // "ALL", "TODAY", "LAST_7_DAYS", "THIS_MONTH"
    val technicianFilter = MutableStateFlow<String?>(null)

    // Table view mode and sorting
    val isTableViewMode = MutableStateFlow(true)
    val tableSortColumn = MutableStateFlow("DATE") // "DATE", "CUSTOMER", "STATUS", "PART"
    val tableSortAscending = MutableStateFlow(false)
    val isDesktopMode = MutableStateFlow(false)

    // Raw streams from Room
    private val allOrdersRaw = repository.allOrders
    val allNotifications = repository.allNotifications.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val unreadNotificationCount = repository.unreadCount.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = 0
    )

    // Stock inventory streams
    val allStock = repository.allSpareParts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    val criticalStock = repository.criticalSpareParts.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Field Staff stream (for management & auth)
    val allStaff = repository.allStaff.stateIn(
        scope = viewModelScope,
        started = SharingStarted.Eagerly,
        initialValue = emptyList()
    )

    // Active Overdue Orders stream (orders overdue > 3 days and not snoozed)
    val overdueOrders: StateFlow<List<PartOrderRequest>> = combine(allOrdersRaw) { ordersArr ->
        ordersArr[0].filter { it.isOverdue && !it.isSnoozed }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Filtered and Sorted orders for Table View & List View
    val filteredOrders: StateFlow<List<PartOrderRequest>> = combine(
        allOrdersRaw,
        searchQuery,
        statusFilter,
        dateFilter,
        technicianFilter,
        tableSortColumn,
        tableSortAscending
    ) { params ->
        val orders = params[0] as List<PartOrderRequest>
        val query = params[1] as String
        val status = params[2] as String?
        val dateFilterType = params[3] as String
        val techFilter = params[4] as String?
        val sortCol = params[5] as String
        val sortAsc = params[6] as Boolean

        val now = System.currentTimeMillis()
        val dayMs = 86400000L

        orders.filter { order ->
            // Status match
            val matchesStatus = status == null || order.status == status

            // Technician match
            val matchesTech = techFilter == null || order.technicianId == techFilter || order.technicianName.contains(techFilter, ignoreCase = true)

            // Date match
            val matchesDate = when (dateFilterType) {
                "TODAY" -> (now - order.createdAt) <= dayMs
                "LAST_7_DAYS" -> (now - order.createdAt) <= (dayMs * 7)
                "THIS_MONTH" -> (now - order.createdAt) <= (dayMs * 30)
                else -> true
            }

            // Text search match across customer, device, part, phone, serial
            val matchesQuery = if (query.isBlank()) true else {
                order.customerName.contains(query, ignoreCase = true) ||
                        order.requiredPartName.contains(query, ignoreCase = true) ||
                        order.requiredPartCode.contains(query, ignoreCase = true) ||
                        order.deviceModel.contains(query, ignoreCase = true) ||
                        order.deviceType.contains(query, ignoreCase = true) ||
                        order.customerPhone.contains(query, ignoreCase = true) ||
                        order.technicianName.contains(query, ignoreCase = true) ||
                        order.faultDescription.contains(query, ignoreCase = true) ||
                        order.id.toString() == query.trim().removePrefix("#")
            }

            matchesStatus && matchesTech && matchesDate && matchesQuery
        }.let { list ->
            // Sort
            when (sortCol) {
                "CUSTOMER" -> if (sortAsc) list.sortedBy { it.customerName } else list.sortedByDescending { it.customerName }
                "PART" -> if (sortAsc) list.sortedBy { it.requiredPartName } else list.sortedByDescending { it.requiredPartName }
                "STATUS" -> if (sortAsc) list.sortedBy { it.status } else list.sortedByDescending { it.status }
                else -> if (sortAsc) list.sortedBy { it.createdAt } else list.sortedByDescending { it.createdAt }
            }
        }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Personnel Performance Metrics
    val personnelPerformance: StateFlow<List<TechnicianPerformance>> = allOrdersRaw.combine(allOrdersRaw) { orders, _ ->
        val techGroups = orders.groupBy { it.technicianName.ifBlank { "Diğer Personel" } }
        techGroups.map { (name, techOrders) ->
            val techId = techOrders.firstOrNull()?.technicianId ?: "tech_unknown"
            val total = techOrders.size
            val completed = techOrders.filter { it.status == OrderStatus.DELIVERED }
            val completedCount = completed.size
            val pendingCount = total - completedCount

            val durationsHours = completed.mapNotNull { order ->
                val end = order.arrivedAt
                if (end != null && end >= order.createdAt) {
                    (end - order.createdAt).toDouble() / 3600000.0
                } else null
            }

            val avgHours = if (durationsHours.isNotEmpty()) durationsHours.average() else 0.0
            val formatted = when {
                durationsHours.isEmpty() -> "Henüz teslimat yok"
                avgHours < 24.0 -> String.format(java.util.Locale.US, "%.1f saat", avgHours)
                else -> String.format(java.util.Locale.US, "%.1f gün", avgHours / 24.0)
            }

            TechnicianPerformance(
                technicianId = techId,
                technicianName = name,
                totalOrders = total,
                completedOrders = completedCount,
                pendingOrders = pendingCount,
                avgCompletionTimeHours = avgHours,
                avgCompletionTimeFormatted = formatted
            )
        }.sortedByDescending { it.totalOrders }
    }.stateIn(
        scope = viewModelScope,
        started = SharingStarted.WhileSubscribed(5000),
        initialValue = emptyList()
    )

    // Selected order for detailed modal
    private val _selectedOrder = MutableStateFlow<PartOrderRequest?>(null)
    val selectedOrder: StateFlow<PartOrderRequest?> = _selectedOrder.asStateFlow()

    // Floating heads-up in-app notification banner
    private val _activeBanner = MutableStateFlow<AppNotification?>(null)
    val activeBanner: StateFlow<AppNotification?> = _activeBanner.asStateFlow()

    // Snackbar alert
    private val _createSuccessMessage = MutableStateFlow<String?>(null)
    val createSuccessMessage: StateFlow<String?> = _createSuccessMessage.asStateFlow()

    val syncedServerUsers = MutableStateFlow<List<UserAccount>>(emptyList())
    private val firestoreSync = com.example.data.firebase.FirestoreSyncManager(application)

    init {
        // Load persistent session ONLY if saved with rememberMe == true
        val savedAccount = sessionManager.getSavedUser()
        _loggedInUser.value = savedAccount

        firestoreSync.startPollingUsers { remoteUsers ->
            syncedServerUsers.value = remoteUsers
        }

        viewModelScope.launch {
            repository.seedSampleDataIfEmpty()
            repository.checkAndNotifyOverdueOrders()
            while (kotlinx.coroutines.currentCoroutineContext()[kotlinx.coroutines.Job]?.isActive != false) {
                kotlinx.coroutines.delay(60_000L)
                repository.checkAndNotifyOverdueOrders()
            }
        }
    }

    fun getLastSavedUsername(): String? = sessionManager.getLastUsername()

    private fun isUsernameMatch(a: String, b: String): Boolean {
        val u1 = a.trim().lowercase()
        val u2 = b.trim().lowercase()
        if (u1 == u2) return true
        if (u1.trimEnd('.') == u2.trimEnd('.')) return true
        if (u1.replace(".", "") == u2.replace(".", "")) return true
        return false
    }

    private fun isPasswordMatch(a: String, b: String): Boolean {
        return a.trim() == b.trim()
    }

    // Auth actions
    fun login(username: String, password: String, rememberMe: Boolean = false): Boolean {
        val cleanUser = username.trim().lowercase()
        val cleanPass = password.trim()

        // 1. Check synced users from web portal / backend (cache first)
        var serverUser = syncedServerUsers.value.find {
            isUsernameMatch(it.username, cleanUser) && isPasswordMatch(it.passwordHash, cleanPass)
        }

        // 2. If not found in memory cache, perform an immediate on-demand fetch from backend
        if (serverUser == null) {
            try {
                val freshUsers = kotlinx.coroutines.runBlocking(kotlinx.coroutines.Dispatchers.IO) {
                    firestoreSync.fetchUsersFromApi()
                }
                if (freshUsers.isNotEmpty()) {
                    syncedServerUsers.value = freshUsers
                    serverUser = freshUsers.find {
                        isUsernameMatch(it.username, cleanUser) && isPasswordMatch(it.passwordHash, cleanPass)
                    }
                }
            } catch (e: Exception) {
                android.util.Log.w("MainViewModel", "On-demand user sync error: ${e.message}")
            }
        }

        if (serverUser != null) {
            sessionManager.saveUserSession(serverUser, rememberMe)
            _loggedInUser.value = serverUser
            return true
        }

        // 3. Check predefined accounts (if any)
        val predefined = PredefinedAccounts.authenticate(cleanUser, cleanPass)
        if (predefined != null) {
            sessionManager.saveUserSession(predefined, rememberMe)
            _loggedInUser.value = predefined
            return true
        }

        // 4. Check dynamic Field Staff members registered in database
        val staffMember = allStaff.value.find {
            isUsernameMatch(it.username, cleanUser) &&
            isPasswordMatch(it.password, cleanPass) &&
            it.isActive
        }
        if (staffMember != null) {
            val staffAccount = UserAccount(
                username = staffMember.username,
                passwordHash = staffMember.password,
                fullName = staffMember.fullName,
                role = UserRole.TECHNICIAN,
                technicianId = staffMember.staffId,
                phone = staffMember.phone
            )
            sessionManager.saveUserSession(staffAccount, rememberMe)
            _loggedInUser.value = staffAccount
            return true
        }

        return false
    }

    fun loginAs(account: UserAccount) {
        sessionManager.saveUserSession(account, true)
        _loggedInUser.value = account
    }

    fun signInWithFirebaseGoogle(
        activity: android.app.Activity,
        targetRole: UserRole,
        onSuccess: () -> Unit,
        onError: (String) -> Unit,
        onCancelled: () -> Unit
    ) {
        firebaseAuthManager.signInWithGoogle(
            activity = activity,
            targetRole = targetRole,
            scope = viewModelScope,
            onSuccess = { account ->
                sessionManager.saveUserSession(account)
                _loggedInUser.value = account
                onSuccess()
            },
            onError = onError,
            onCancelled = onCancelled
        )
    }

    fun logout() {
        sessionManager.clearSession()
        _loggedInUser.value = null
        firebaseAuthManager.signOut(viewModelScope) {}
    }

    fun toggleRole() {
        val current = _loggedInUser.value ?: return
        val newAccount = if (current.role == UserRole.TECHNICIAN) {
            PredefinedAccounts.accounts.find { it.role == UserRole.HEADQUARTERS } ?: current
        } else {
            PredefinedAccounts.accounts.find { it.role == UserRole.TECHNICIAN } ?: current
        }
        loginAs(newAccount)
    }

    // Order actions
    fun selectOrder(order: PartOrderRequest?) {
        _selectedOrder.value = order
    }

    fun dismissBanner() {
        _activeBanner.value = null
    }

    fun clearCreateSuccessMessage() {
        _createSuccessMessage.value = null
    }

    fun setTableSort(col: String) {
        if (tableSortColumn.value == col) {
            tableSortAscending.value = !tableSortAscending.value
        } else {
            tableSortColumn.value = col
            tableSortAscending.value = true
        }
    }

    fun setCustomTechnician(name: String, techId: String? = null) {
        val trimmed = name.trim()
        if (trimmed.isBlank()) return
        val current = _loggedInUser.value
        val updated = (current ?: UserAccount(
            username = trimmed.lowercase().replace(" ", "."),
            passwordHash = "1234",
            fullName = trimmed,
            role = UserRole.TECHNICIAN,
            technicianId = techId ?: "tech_${System.currentTimeMillis() % 1000}",
            phone = "0500 000 0000"
        )).copy(
            fullName = trimmed,
            role = UserRole.TECHNICIAN,
            technicianId = techId ?: current?.technicianId ?: "tech_${System.currentTimeMillis() % 1000}"
        )
        sessionManager.saveUserSession(updated)
        _loggedInUser.value = updated
    }

    fun createRequest(
        customerName: String,
        customerPhone: String,
        customerAddress: String,
        deviceType: String,
        deviceModel: String,
        deviceSerial: String,
        faultDescription: String,
        devicePhotoUri: String?,
        requiredPartName: String,
        requiredPartCode: String,
        requiredPartDescription: String,
        requiredPartPhotoUri: String?,
        isStockDeducted: Boolean,
        partQuantity: Int,
        technicianName: String? = null,
        technicianId: String? = null,
        onSuccess: () -> Unit
    ) {
        viewModelScope.launch {
            val assignedTechName = if (!technicianName.isNullOrBlank()) technicianName.trim() else activeTechnicianName
            val assignedTechId = if (!technicianId.isNullOrBlank()) technicianId.trim() else activeTechnicianId
            val newOrder = PartOrderRequest(
                customerName = customerName.trim(),
                customerPhone = customerPhone.trim(),
                customerAddress = customerAddress.trim(),
                deviceType = deviceType.trim(),
                deviceModel = deviceModel.trim(),
                deviceSerial = deviceSerial.trim(),
                faultDescription = faultDescription.trim(),
                devicePhotoUri = devicePhotoUri,
                requiredPartName = requiredPartName.trim(),
                requiredPartCode = requiredPartCode.trim(),
                requiredPartDescription = requiredPartDescription.trim(),
                requiredPartPhotoUri = requiredPartPhotoUri,
                isStockDeducted = isStockDeducted,
                partQuantity = partQuantity,
                technicianName = assignedTechName,
                technicianId = assignedTechId,
                status = OrderStatus.PENDING
            )
            repository.createOrder(newOrder)
            _createSuccessMessage.value = "‘${newOrder.customerName}’ için talep kaydedildi."
            onSuccess()
        }
    }

    fun markOrderPlaced(
        order: PartOrderRequest,
        supplier: String,
        refNumber: String,
        notes: String
    ) {
        viewModelScope.launch {
            val notification = repository.markOrderPlaced(order, supplier, refNumber, notes)
            _activeBanner.value = notification
            _selectedOrder.value = order.copy(
                status = OrderStatus.ORDERED,
                orderPlacedAt = System.currentTimeMillis(),
                orderSupplier = supplier,
                orderRefNumber = refNumber,
                orderNotes = notes
            )
        }
    }

    fun markOrderDelivered(
        order: PartOrderRequest,
        arrivedPhotoUri: String?,
        arrivalNotes: String
    ) {
        viewModelScope.launch {
            val notification = repository.markOrderDelivered(order, arrivedPhotoUri, arrivalNotes)
            _activeBanner.value = notification
            _selectedOrder.value = order.copy(
                status = OrderStatus.DELIVERED,
                arrivedAt = System.currentTimeMillis(),
                arrivedPartPhotoUri = arrivedPhotoUri,
                arrivalNotes = arrivalNotes
            )
        }
    }

    // Stock inventory updates
    fun updatePartStock(partId: Long, newQuantity: Int) {
        viewModelScope.launch {
            repository.updateStock(partId, newQuantity)
        }
    }

    fun addNewPart(
        code: String,
        name: String,
        category: String,
        quantity: Int,
        criticalLevel: Int,
        price: Double,
        shelf: String
    ) {
        viewModelScope.launch {
            val newPart = SparePartItem(
                partCode = code.trim(),
                partName = name.trim(),
                category = category.trim(),
                stockQuantity = quantity,
                minCriticalLevel = criticalLevel,
                unitPrice = price,
                locationShelf = shelf.trim().ifBlank { "Merkez Depo" }
            )
            repository.addSparePart(newPart)
        }
    }

    fun markNotificationAsRead(id: Long) {
        viewModelScope.launch {
            repository.markNotificationAsRead(id)
        }
    }

    fun markAllNotificationsAsRead() {
        viewModelScope.launch {
            repository.markAllNotificationsAsRead()
        }
    }

    fun openOrderByNotification(notification: AppNotification) {
        viewModelScope.launch {
            repository.markNotificationAsRead(notification.id)
            dismissBanner()
            val found = allOrdersRaw.stateIn(viewModelScope).value.find { it.id == notification.orderId }
            if (found != null) {
                _selectedOrder.value = found
            }
        }
    }

    // --- Field Staff Management Actions (Headquarters) ---
    fun addStaff(
        fullName: String,
        username: String,
        password: String,
        phone: String,
        title: String,
        isActive: Boolean = true
    ) {
        viewModelScope.launch {
            val randomSuffix = (10 + (Math.random() * 89)).toInt()
            val newStaff = com.example.data.model.FieldStaffMember(
                staffId = "tech_$randomSuffix",
                fullName = fullName.trim(),
                username = username.trim().lowercase(),
                password = password.trim(),
                phone = phone.trim(),
                title = title.trim().ifBlank { "Saha Teknisyeni" },
                isActive = isActive
            )
            repository.addStaff(newStaff)
        }
    }

    fun updateStaff(staff: com.example.data.model.FieldStaffMember) {
        viewModelScope.launch {
            repository.updateStaff(staff)
        }
    }

    fun deleteStaff(staffId: Long) {
        viewModelScope.launch {
            repository.deleteStaff(staffId)
        }
    }

    // --- Overdue Alert & 3-Day Snooze Actions ---
    fun snoozeOrder(order: PartOrderRequest, days: Int = 3) {
        viewModelScope.launch {
            repository.snoozeOrderNotification(order.id, days)
        }
    }

    fun triggerOverdueCheck() {
        viewModelScope.launch {
            repository.checkAndNotifyOverdueOrders()
        }
    }
}
