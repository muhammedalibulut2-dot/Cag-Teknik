package com.example.ui.components

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Hardware
import androidx.compose.material.icons.filled.HomeRepairService
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilledTonalButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import coil.compose.AsyncImage

data class PresetPhotoItem(
    val id: String,
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val gradientColors: List<Color>
)

object PresetPhotos {
    val items = listOf(
        PresetPhotoItem(
            id = "preset:pompa",
            title = "Sirkülasyon Pompası",
            subtitle = "Kombi / Isıtma Devri",
            icon = Icons.Default.Build,
            gradientColors = listOf(Color(0xFF1E3A8A), Color(0xFF3B82F6))
        ),
        PresetPhotoItem(
            id = "preset:anakart",
            title = "Elektronik Kontrol Kartı",
            subtitle = "PCB / İnvertör Kart",
            icon = Icons.Default.Memory,
            gradientColors = listOf(Color(0xFF047857), Color(0xFF10B981))
        ),
        PresetPhotoItem(
            id = "preset:step_motor",
            title = "Flap / Fan Motoru",
            subtitle = "Klima & Soğutma Motoru",
            icon = Icons.Default.Settings,
            gradientColors = listOf(Color(0xFFB45309), Color(0xFFF59E0B))
        ),
        PresetPhotoItem(
            id = "preset:ventil",
            title = "3 Yollu Vana & Ventil",
            subtitle = "Su & Gaz Yönlendirme",
            icon = Icons.Default.Hardware,
            gradientColors = listOf(Color(0xFF6D28D9), Color(0xFF8B5CF6))
        ),
        PresetPhotoItem(
            id = "preset:kombi",
            title = "Cihaz: Duvar Tipi Kombi",
            subtitle = "Panel & Hidrolik Blok",
            icon = Icons.Default.HomeRepairService,
            gradientColors = listOf(Color(0xFF0F172A), Color(0xFF334155))
        ),
        PresetPhotoItem(
            id = "preset:buzdolabi",
            title = "Cihaz: No-Frost Buzdolabı",
            subtitle = "Kompresör & Gövde",
            icon = Icons.Default.ElectricBolt,
            gradientColors = listOf(Color(0xFF0369A1), Color(0xFF0284C7))
        ),
        PresetPhotoItem(
            id = "preset:step_motor_gelen",
            title = "Teslim Alınan Orijinal Parça",
            subtitle = "Barkodlu Paket & Parça",
            icon = Icons.Default.CheckCircle,
            gradientColors = listOf(Color(0xFF065F46), Color(0xFF059669))
        )
    )

    fun find(id: String?): PresetPhotoItem? {
        if (id == null) return null
        return items.find { it.id == id }
    }
}

@Composable
fun TechnicalPhotoThumbnail(
    photoUri: String?,
    modifier: Modifier = Modifier,
    height: Dp = 120.dp,
    label: String? = null,
    onClick: (() -> Unit)? = null
) {
    var showFullDialog by remember { mutableStateOf(false) }

    val preset = PresetPhotos.find(photoUri)
    val isRealUri = photoUri != null && !photoUri.startsWith("preset:")

    Box(
        modifier = modifier
            .height(height)
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(1.dp, MaterialTheme.colorScheme.outlineVariant, RoundedCornerShape(12.dp))
            .clickable(enabled = photoUri != null) {
                if (onClick != null) onClick() else showFullDialog = true
            },
        contentAlignment = Alignment.Center
    ) {
        if (photoUri == null) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center,
                modifier = Modifier.padding(8.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Image,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                    modifier = Modifier.size(28.dp)
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = label ?: "Fotoğraf Eklenmedi",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                )
            }
        } else if (preset != null) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Brush.linearGradient(preset.gradientColors))
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = Color.White.copy(alpha = 0.25f),
                            modifier = Modifier.size(26.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = preset.icon,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = Color.Black.copy(alpha = 0.35f)
                        ) {
                            Text(
                                text = "GÖRSEL",
                                color = Color.White,
                                fontSize = 9.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Column {
                        Text(
                            text = preset.title,
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            maxLines = 1
                        )
                        Text(
                            text = preset.subtitle,
                            color = Color.White.copy(alpha = 0.85f),
                            fontSize = 10.sp,
                            maxLines = 1
                        )
                    }
                }
            }
        } else if (isRealUri) {
            AsyncImage(
                model = photoUri,
                contentDescription = label ?: "Fotoğraf",
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        }
    }

    if (showFullDialog && photoUri != null) {
        Dialog(onDismissRequest = { showFullDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = label ?: "Fotoğraf Detayı",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                        IconButton(onClick = { showFullDialog = false }) {
                            Icon(Icons.Default.Close, contentDescription = "Kapat")
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    if (preset != null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(220.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(Brush.linearGradient(preset.gradientColors))
                                .padding(16.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = preset.icon,
                                    contentDescription = null,
                                    tint = Color.White,
                                    modifier = Modifier.size(64.dp)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = preset.title,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 18.sp
                                )
                                Text(
                                    text = preset.subtitle,
                                    color = Color.White.copy(alpha = 0.9f),
                                    fontSize = 13.sp
                                )
                            }
                        }
                    } else if (isRealUri) {
                        AsyncImage(
                            model = photoUri,
                            contentDescription = label,
                            contentScale = ContentScale.Fit,
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(260.dp)
                                .clip(RoundedCornerShape(12.dp))
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedButton(
                        onClick = { showFullDialog = false },
                        modifier = Modifier.align(Alignment.End)
                    ) {
                        Text("Tamam")
                    }
                }
            }
        }
    }
}
