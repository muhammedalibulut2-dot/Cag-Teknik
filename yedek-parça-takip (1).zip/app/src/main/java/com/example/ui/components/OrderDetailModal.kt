package com.example.ui.components

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.LocalShipping
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.DividerDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.model.OrderStatus
import com.example.data.model.PartOrderRequest
import com.example.data.model.UserRole
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun OrderDetailModal(
    order: PartOrderRequest,
    currentRole: UserRole,
    onDismiss: () -> Unit,
    onMarkOrderPlaced: (supplier: String, refNumber: String, notes: String) -> Unit,
    onMarkOrderDelivered: (arrivedPhotoUri: String?, arrivalNotes: String) -> Unit,
    onSnooze: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val dateFormat = remember { SimpleDateFormat("dd.MM.yyyy HH:mm", Locale("tr")) }

    // Dialog states for headquarters actions
    var showOrderPlacementDialog by remember { mutableStateOf(false) }
    var showDeliveryDialog by remember { mutableStateOf(false) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxSize()
                .padding(top = 28.dp),
            shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
            color = MaterialTheme.colorScheme.background
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                // Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "TALEP #${order.id}",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            StatusBadge(status = order.status)
                        }
                        Text(
                            text = order.customerName,
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold
                        )
                    }
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier.testTag("close_order_detail_button")
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Kapat")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp))

                // Scrollable Content
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // Timeline tracker card
                    OrderTimelineCard(order = order, dateFormat = dateFormat)

                    // Overdue Alert Banner in Modal
                    if (order.isOverdue) {
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color(0xFFFEF2F2)),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                            modifier = Modifier.fillMaxWidth().testTag("modal_overdue_banner")
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Icon(
                                            Icons.Default.Warning,
                                            contentDescription = null,
                                            tint = Color(0xFFDC2626),
                                            modifier = Modifier.size(20.dp)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = "⚠️ 3 Günden Fazla Geciken Sipariş (${order.overdueDaysCount} gün)",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp,
                                                color = Color(0xFF991B1B)
                                            )
                                            Text(
                                                text = if (order.isSnoozed) "Bildirim 3 gün ertelenmiştir. Süre bitiminde parça hala teslim edilmemişse tekrar uyarı verilecektir."
                                                else "Tedarikçiden henüz teslim alınamadı. 3 gün erteleyebilir veya teslimat girişi yapabilirsiniz.",
                                                fontSize = 11.sp,
                                                color = Color(0xFF7F1D1D)
                                            )
                                        }
                                    }

                                    if (currentRole == UserRole.HEADQUARTERS && onSnooze != null) {
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Button(
                                            onClick = onSnooze,
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE11D48)),
                                            modifier = Modifier.testTag("modal_btn_snooze")
                                        ) {
                                            Icon(Icons.Default.Schedule, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("3G Ertele", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }
                        }
                    }

                    // Customer Information Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Müşteri Bilgileri",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column {
                                    Text(
                                        text = order.customerName,
                                        fontWeight = FontWeight.SemiBold,
                                        fontSize = 16.sp
                                    )
                                    Text(
                                        text = order.customerPhone,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                                        fontSize = 14.sp
                                    )
                                }
                                Row {
                                    IconButton(
                                        onClick = {
                                            val intent = Intent(Intent.ACTION_DIAL).apply {
                                                data = Uri.parse("tel:${order.customerPhone}")
                                            }
                                            context.startActivity(intent)
                                        },
                                        modifier = Modifier.testTag("call_customer_button")
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.primaryContainer,
                                            modifier = Modifier.size(38.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    Icons.Default.Phone,
                                                    contentDescription = "Ara",
                                                    tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                    IconButton(
                                        onClick = {
                                            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                                type = "text/plain"
                                                putExtra(
                                                    Intent.EXTRA_TEXT,
                                                    "Sipariş No: #${order.id}\nMüşteri: ${order.customerName}\nParça: ${order.requiredPartName}\nDurum: ${OrderStatus.getLabel(order.status)}"
                                                )
                                            }
                                            context.startActivity(Intent.createChooser(shareIntent, "Paylaş"))
                                        }
                                    ) {
                                        Surface(
                                            shape = CircleShape,
                                            color = MaterialTheme.colorScheme.secondaryContainer,
                                            modifier = Modifier.size(38.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center) {
                                                Icon(
                                                    Icons.Default.Share,
                                                    contentDescription = "Paylaş",
                                                    tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(8.dp))
                            Row(verticalAlignment = Alignment.Top) {
                                Icon(
                                    Icons.Default.LocationOn,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = order.customerAddress,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }

                    // Device & Fault Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Cihaz & Arıza Detayı",
                                fontWeight = FontWeight.Bold,
                                fontSize = 15.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(10.dp))

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = "${order.deviceType} • ${order.deviceModel}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp
                                    )
                                    if (order.deviceSerial.isNotBlank()) {
                                        Text(
                                            text = "Seri No: ${order.deviceSerial}",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = order.faultDescription,
                                        fontSize = 13.sp,
                                        lineHeight = 18.sp
                                    )
                                }
                                if (order.devicePhotoUri != null) {
                                    Spacer(modifier = Modifier.width(12.dp))
                                    TechnicalPhotoThumbnail(
                                        photoUri = order.devicePhotoUri,
                                        modifier = Modifier.width(100.dp),
                                        height = 80.dp,
                                        label = "Cihaz Görseli"
                                    )
                                }
                            }
                        }
                    }

                    // Required Spare Part Card
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.surface
                        ),
                        border = androidx.compose.foundation.BorderStroke(
                            1.5.dp,
                            MaterialTheme.colorScheme.primary.copy(alpha = 0.2f)
                        ),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "İstenen Yedek Parça",
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp,
                                    color = MaterialTheme.colorScheme.primary
                                )
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = MaterialTheme.colorScheme.primaryContainer
                                ) {
                                    Text(
                                        text = order.technicianName,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(10.dp))

                            Text(
                                text = order.requiredPartName,
                                fontWeight = FontWeight.Bold,
                                fontSize = 17.sp,
                                color = MaterialTheme.colorScheme.primary
                            )
                            if (order.requiredPartCode.isNotBlank()) {
                                Text(
                                    text = "Parça Kodu / OEM: ${order.requiredPartCode}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            if (order.requiredPartDescription.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = order.requiredPartDescription,
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Text(
                                text = "Gerekli Parça Görseli:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            TechnicalPhotoThumbnail(
                                photoUri = order.requiredPartPhotoUri,
                                modifier = Modifier.fillMaxWidth(),
                                height = 130.dp,
                                label = "İstenen Parça Görseli"
                            )
                        }
                    }

                    // Arrived / Delivered Part Card (when delivered)
                    if (order.status == OrderStatus.DELIVERED) {
                        Card(
                            shape = RoundedCornerShape(16.dp),
                            colors = CardDefaults.cardColors(
                                containerColor = Color(0xFFF0FDF4)
                            ),
                            border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0xFF10B981)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(16.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = Color(0xFF059669),
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "Gelen Parça & Teslimat Bilgisi",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 15.sp,
                                        color = Color(0xFF065F46)
                                    )
                                }
                                Spacer(modifier = Modifier.height(10.dp))

                                if (order.arrivalNotes != null) {
                                    Text(
                                        text = "Merkez Notu: ${order.arrivalNotes}",
                                        fontSize = 13.sp,
                                        color = Color(0xFF065F46)
                                    )
                                }

                                Spacer(modifier = Modifier.height(10.dp))
                                Text(
                                    text = "Merkez Ofisin Eklediği Gelen Parça Fotoğrafı:",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF065F46)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                TechnicalPhotoThumbnail(
                                    photoUri = order.arrivedPartPhotoUri,
                                    modifier = Modifier.fillMaxWidth(),
                                    height = 140.dp,
                                    label = "Gelen Parça Fotoğrafı"
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                }

                // Bottom Action Bar depending on UserRole & Order Status
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        if (currentRole == UserRole.HEADQUARTERS) {
                            when (order.status) {
                                OrderStatus.PENDING -> {
                                    Button(
                                        onClick = { showOrderPlacementDialog = true },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("action_order_placed_button"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = MaterialTheme.colorScheme.primary
                                        )
                                    ) {
                                        Icon(Icons.Default.LocalShipping, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "Sipariş Geçildi Olarak Seç",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 15.sp
                                        )
                                    }
                                }
                                OrderStatus.ORDERED -> {
                                    Button(
                                        onClick = { showDeliveryDialog = true },
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .height(50.dp)
                                            .testTag("action_mark_delivered_button"),
                                        colors = ButtonDefaults.buttonColors(
                                            containerColor = Color(0xFF059669)
                                        )
                                    ) {
                                        Icon(Icons.Default.DoneAll, contentDescription = null)
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            "Sipariş Teslim Edildi Seç (Fotoğraf Ekle)",
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.sp
                                        )
                                    }
                                }
                                OrderStatus.DELIVERED -> {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.Center,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Icon(
                                            Icons.Default.CheckCircle,
                                            contentDescription = null,
                                            tint = Color(0xFF059669)
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = "Bu sipariş başarıyla tamamlandı ve teslim edildi.",
                                            fontWeight = FontWeight.SemiBold,
                                            fontSize = 13.sp,
                                            color = Color(0xFF059669)
                                        )
                                    }
                                }
                            }
                        } else {
                            // Saha Personeli View
                            when (order.status) {
                                OrderStatus.PENDING -> {
                                    Text(
                                        text = "⏳ Talep merkeze iletildi. Ana hesap incelemesi ve siparişi bekleniyor.",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Medium,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                OrderStatus.ORDERED -> {
                                    Text(
                                        text = "📦 Merkez ofis siparişi tedarikçiye geçti. Parça ulaştığında bildirim gelecektir.",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.SemiBold,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                }
                                OrderStatus.DELIVERED -> {
                                    Text(
                                        text = "✅ Parça teslim edildi! Yukarıdaki gelen parça fotoğrafını inceleyip montaja başlayabilirsiniz.",
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color(0xFF059669)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Modal 1: Sipariş Geçildi (Order Placed) Dialog
    if (showOrderPlacementDialog) {
        var supplier by remember { mutableStateOf("Merkez Yedek Parça Dağıtım A.Ş.") }
        var refNumber by remember { mutableStateOf("SIP-${System.currentTimeMillis() % 100000}") }
        var notes by remember { mutableStateOf("Tedarikçiye sipariş geçildi. Yarın teslim edilecek.") }

        Dialog(onDismissRequest = { showOrderPlacementDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = "Siparişi Onayla",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Bu işlem yapıldığında mobil kullanıcıya \"‘${order.customerName}’ adlı müşterinin siparişi oluşturuldu\" bildirimi gönderilecektir.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    OutlinedTextField(
                        value = supplier,
                        onValueChange = { supplier = it },
                        label = { Text("Tedarikçi / Dağıtıcı") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = refNumber,
                        onValueChange = { refNumber = it },
                        label = { Text("Sipariş Takip Kodu") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Sipariş Notu") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(onClick = { showOrderPlacementDialog = false }) {
                            Text("İptal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                showOrderPlacementDialog = false
                                onMarkOrderPlaced(supplier, refNumber, notes)
                            },
                            modifier = Modifier.testTag("confirm_order_placed_button")
                        ) {
                            Text("Siparişi Geç & Bildir")
                        }
                    }
                }
            }
        }
    }

    // Modal 2: Sipariş Teslim Edildi (Part Arrived) Dialog with Photo Attachment
    if (showDeliveryDialog) {
        var arrivedPhotoUri by remember { mutableStateOf<String?>("preset:step_motor_gelen") }
        var arrivalNotes by remember { mutableStateOf("Parça merkez depoda teslim alındı, sağlam ve kullanıma hazır.") }
        var showPhotoPicker by remember { mutableStateOf(false) }

        Dialog(onDismissRequest = { showDeliveryDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp)
            ) {
                Column(
                    modifier = Modifier
                        .padding(20.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Text(
                        text = "Parça Teslim Alındı & Onay",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "Parça merkeze ulaştığında gelen parça fotoğrafını ekleyin. Mobil kullanıcıya \"‘${order.customerName}’ adlı müşterinin siparişi teslim edildi\" bildirimi iletilecektir.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 8.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "Gelen Parça Fotoğrafı:",
                        fontWeight = FontWeight.SemiBold,
                        fontSize = 13.sp
                    )
                    Spacer(modifier = Modifier.height(6.dp))

                    TechnicalPhotoThumbnail(
                        photoUri = arrivedPhotoUri,
                        modifier = Modifier.fillMaxWidth(),
                        height = 120.dp,
                        label = "Gelen Parça Görseli",
                        onClick = { showPhotoPicker = true }
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedButton(
                        onClick = { showPhotoPicker = true },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("add_arrived_part_photo_button")
                    ) {
                        Icon(Icons.Default.AddAPhoto, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(if (arrivedPhotoUri == null) "Gelen Parça Fotoğrafı Ekle" else "Fotoğrafı Değiştir")
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    OutlinedTextField(
                        value = arrivalNotes,
                        onValueChange = { arrivalNotes = it },
                        label = { Text("Teslimat / Kalite Kontrol Notu") },
                        modifier = Modifier.fillMaxWidth(),
                        maxLines = 3
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        OutlinedButton(onClick = { showDeliveryDialog = false }) {
                            Text("İptal")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                showDeliveryDialog = false
                                onMarkOrderDelivered(arrivedPhotoUri, arrivalNotes)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF059669)),
                            modifier = Modifier.testTag("confirm_delivery_button")
                        ) {
                            Text("Teslim Edildi Olarak Kaydet")
                        }
                    }
                }
            }
        }

        if (showPhotoPicker) {
            PhotoPickerModal(
                title = "Gelen Parça Fotoğrafı Seç",
                onDismiss = { showPhotoPicker = false },
                onPhotoSelected = { uri ->
                    arrivedPhotoUri = uri
                }
            )
        }
    }
}

@Composable
fun OrderTimelineCard(order: PartOrderRequest, dateFormat: SimpleDateFormat) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                text = "Sipariş & Teslimat Aşamaları",
                fontWeight = FontWeight.Bold,
                fontSize = 15.sp,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(14.dp))

            // Step 1: Talep Alındı
            TimelineStepItem(
                title = "1. Talep Oluşturuldu (Saha)",
                subtitle = "${order.technicianName} tarafından kaydedildi",
                dateString = dateFormat.format(Date(order.createdAt)),
                isCompleted = true,
                isActive = order.status == OrderStatus.PENDING,
                icon = Icons.Default.Handyman
            )

            // Step 2: Sipariş Geçildi
            val isOrderedCompleted = order.status == OrderStatus.ORDERED || order.status == OrderStatus.DELIVERED
            TimelineStepItem(
                title = "2. Sipariş Geçildi (Merkez)",
                subtitle = if (order.orderSupplier != null) "Tedarikçi: ${order.orderSupplier} • Ref: ${order.orderRefNumber}" else "Merkez ofis onayı bekleniyor",
                dateString = if (order.orderPlacedAt != null) dateFormat.format(Date(order.orderPlacedAt)) else "Beklemede",
                isCompleted = isOrderedCompleted,
                isActive = order.status == OrderStatus.ORDERED,
                icon = Icons.Default.LocalShipping
            )

            // Step 3: Teslim Edildi
            val isDelivered = order.status == OrderStatus.DELIVERED
            TimelineStepItem(
                title = "3. Parça Geldi & Teslim Edildi",
                subtitle = if (isDelivered) (order.arrivalNotes ?: "Parça teslim alındı") else "Merkeze ulaşması bekleniyor",
                dateString = if (order.arrivedAt != null) dateFormat.format(Date(order.arrivedAt)) else "Beklemede",
                isCompleted = isDelivered,
                isActive = isDelivered,
                icon = Icons.Default.CheckCircle,
                isLast = true
            )
        }
    }
}

@Composable
fun TimelineStepItem(
    title: String,
    subtitle: String,
    dateString: String,
    isCompleted: Boolean,
    isActive: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    isLast: Boolean = false
) {
    val activeColor = if (isCompleted) Color(0xFF059669) else MaterialTheme.colorScheme.outlineVariant

    Row(modifier = Modifier.fillMaxWidth()) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Surface(
                shape = CircleShape,
                color = if (isCompleted) Color(0xFF059669) else Color.LightGray.copy(alpha = 0.5f),
                modifier = Modifier.size(28.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = if (isCompleted) Color.White else Color.Gray,
                        modifier = Modifier.size(16.dp)
                    )
                }
            }
            if (!isLast) {
                Box(
                    modifier = Modifier
                        .width(2.dp)
                        .height(38.dp)
                        .background(if (isCompleted) Color(0xFF059669) else Color.LightGray.copy(alpha = 0.5f))
                )
            }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.padding(bottom = if (isLast) 0.dp else 12.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = title,
                    fontWeight = if (isActive || isCompleted) FontWeight.Bold else FontWeight.Medium,
                    fontSize = 13.sp,
                    color = if (isCompleted) MaterialTheme.colorScheme.onSurface else MaterialTheme.colorScheme.onSurfaceVariant
                )
                Text(
                    text = dateString,
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
            Text(
                text = subtitle,
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val (bgColor, textColor, text) = when (status) {
        OrderStatus.PENDING -> Triple(Color(0xFFFEF3C7), Color(0xFF92400E), "Beklemede")
        OrderStatus.ORDERED -> Triple(Color(0xFFDBEAFE), Color(0xFF1E40AF), "Sipariş Geçildi")
        OrderStatus.DELIVERED -> Triple(Color(0xFFD1FAE5), Color(0xFF065F46), "Teslim Edildi")
        else -> Triple(Color(0xFFF1F5F9), Color(0xFF334155), status)
    }

    Surface(
        shape = RoundedCornerShape(6.dp),
        color = bgColor
    ) {
        Text(
            text = text,
            color = textColor,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}
