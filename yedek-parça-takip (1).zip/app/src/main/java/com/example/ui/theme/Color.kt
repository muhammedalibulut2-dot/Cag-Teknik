package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Industrial Navy & Electric Blue Palette
val PrimaryNavy = Color(0xFF1E3A8A)
val PrimaryNavyDark = Color(0xFF3B82F6)
val PrimaryNavyContainer = Color(0xFFDBEAFE)
val OnPrimaryNavyContainer = Color(0xFF1E40AF)

val SecondaryTeal = Color(0xFF0284C7)
val SecondaryTealContainer = Color(0xFFE0F2FE)

val AccentAmber = Color(0xFFD97706)
val AccentAmberContainer = Color(0xFFFEF3C7)
val OnAccentAmberContainer = Color(0xFF92400E)

val SuccessEmerald = Color(0xFF059669)
val SuccessEmeraldContainer = Color(0xFFD1FAE5)
val OnSuccessEmeraldContainer = Color(0xFF065F46)

val BackgroundLight = Color(0xFFF8FAFC)
val SurfaceLight = Color(0xFFFFFFFF)
val SurfaceVariantLight = Color(0xFFF1F5F9)

val BackgroundDark = Color(0xFF0F172A)
val SurfaceDark = Color(0xFF1E293B)
val SurfaceVariantDark = Color(0xFF334155)

val TextPrimaryLight = Color(0xFF0F172A)
val TextSecondaryLight = Color(0xFF64748B)

val TextPrimaryDark = Color(0xFFF8FAFC)
val TextSecondaryDark = Color(0xFF94A3B8)
