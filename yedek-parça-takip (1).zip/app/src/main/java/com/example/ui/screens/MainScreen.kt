package com.example.ui.screens

import android.Manifest
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Assessment
import androidx.compose.material.icons.filled.Engineering
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material.icons.filled.Handyman
import androidx.compose.material.icons.filled.Inventory
import androidx.compose.material.icons.filled.ListAlt
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material.icons.filled.TableChart
import androidx.compose.material3.Badge
import androidx.compose.material3.BadgedBox
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.R
import com.example.data.model.UserRole
import com.example.ui.components.AdvancedSearchTableView
import com.example.ui.components.InAppNotificationBanner
import com.example.ui.components.OrderDetailModal
import com.example.ui.viewmodel.MainViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(viewModel: MainViewModel) {
    val loggedInUser by viewModel.loggedInUser.collectAsStateWithLifecycle()

    // If not authenticated, render LoginScreen
    if (loggedInUser == null) {
        LoginScreen(viewModel = viewModel)
        return
    }

    var selectedTab by remember { mutableIntStateOf(0) }
    val currentRole by viewModel.currentRole.collectAsStateWithLifecycle()
    val unreadCount by viewModel.unreadNotificationCount.collectAsStateWithLifecycle()
    val activeBanner by viewModel.activeBanner.collectAsStateWithLifecycle()
    val selectedOrder by viewModel.selectedOrder.collectAsStateWithLifecycle()
    val successMsg by viewModel.createSuccessMessage.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    var showUserMenu by remember { mutableStateOf(false) }

    // Request notification permission on Android 13+
    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { _ -> }

    LaunchedEffect(Unit) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    LaunchedEffect(successMsg) {
        if (successMsg != null) {
            snackbarHostState.showSnackbar(successMsg!!)
            viewModel.clearCreateSuccessMessage()
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.Center
                    ) {
                        // User uploaded Çağ Teknik Logo
                        Box(
                            modifier = Modifier
                                .size(34.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .border(1.dp, Color(0xFF0284C7).copy(alpha = 0.5f), RoundedCornerShape(8.dp))
                                .background(Color(0xFF0B132B)),
                            contentAlignment = Alignment.Center
                        ) {
                            Image(
                                painter = painterResource(id = R.drawable.app_logo),
                                contentDescription = "Logo",
                                modifier = Modifier.fillMaxSize(),
                                contentScale = ContentScale.Crop
                            )
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Yedek Parça Takip",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = if (currentRole == UserRole.HEADQUARTERS) "Ana Hesap • Merkez Ofis" else "${loggedInUser?.fullName}",
                                fontSize = 10.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                maxLines = 1
                            )
                        }
                    }
                },
                navigationIcon = {
                    // Profile Chip & Switcher Menu
                    Box {
                        Surface(
                            shape = RoundedCornerShape(20.dp),
                            color = if (currentRole == UserRole.TECHNICIAN) {
                                MaterialTheme.colorScheme.secondaryContainer
                            } else {
                                MaterialTheme.colorScheme.primaryContainer
                            },
                            modifier = Modifier
                                .padding(start = 10.dp)
                                .clickable { showUserMenu = true }
                                .testTag("top_bar_role_toggle")
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = if (currentRole == UserRole.TECHNICIAN) Icons.Default.Handyman else Icons.Default.AdminPanelSettings,
                                    contentDescription = null,
                                    modifier = Modifier.size(14.dp),
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (currentRole == UserRole.TECHNICIAN) "Saha" else "Merkez",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Spacer(modifier = Modifier.width(2.dp))
                                Icon(
                                    Icons.Default.SwapHoriz,
                                    contentDescription = "Rol",
                                    modifier = Modifier.size(12.dp),
                                    tint = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.7f)
                                )
                            }
                        }

                        DropdownMenu(
                            expanded = showUserMenu,
                            onDismissRequest = { showUserMenu = false }
                        ) {
                            DropdownMenuItem(
                                text = {
                                    Column {
                                        Text(text = loggedInUser?.fullName ?: "", fontWeight = FontWeight.Bold)
                                        Text(
                                            text = if (currentRole == UserRole.HEADQUARTERS) "Merkez Yetkili" else "Saha Teknisyeni",
                                            fontSize = 11.sp,
                                            color = Color.Gray
                                        )
                                    }
                                },
                                onClick = { showUserMenu = false }
                            )
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.SwapHoriz, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(if (currentRole == UserRole.HEADQUARTERS) "Sahaya Geçiş Yap" else "Merkeze Geçiş Yap")
                                    }
                                },
                                onClick = {
                                    showUserMenu = false
                                    viewModel.toggleRole()
                                }
                            )
                            if (currentRole == UserRole.HEADQUARTERS) {
                                DropdownMenuItem(
                                    text = {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Engineering, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("Saha Personeli Yönetimi")
                                        }
                                    },
                                    onClick = {
                                        showUserMenu = false
                                        selectedTab = 3
                                    }
                                )
                            }
                            DropdownMenuItem(
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.ExitToApp, contentDescription = null, tint = Color.Red, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text("Çıkış Yap", color = Color.Red)
                                    }
                                },
                                onClick = {
                                    showUserMenu = false
                                    viewModel.logout()
                                }
                            )
                        }
                    }
                },
                actions = {
                    if (currentRole == UserRole.HEADQUARTERS) {
                        IconButton(
                            onClick = { selectedTab = 3 },
                            modifier = Modifier.testTag("top_staff_management_button")
                        ) {
                            Icon(
                                Icons.Default.Engineering,
                                contentDescription = "Personel Yönetimi",
                                tint = if (selectedTab == 3) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                    IconButton(
                        onClick = {
                            selectedTab = if (currentRole == UserRole.HEADQUARTERS) 4 else 3
                        },
                        modifier = Modifier.testTag("notifications_top_icon")
                    ) {
                        BadgedBox(
                            badge = {
                                if (unreadCount > 0) {
                                    Badge {
                                        Text("$unreadCount")
                                    }
                                }
                            }
                        ) {
                            Icon(
                                Icons.Default.Notifications,
                                contentDescription = "Bildirimler"
                            )
                        }
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface
                )
            )
        },
        bottomBar = {
            NavigationBar(
                containerColor = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                if (currentRole == UserRole.HEADQUARTERS) {
                    // Ana Hesap Tab Bar (3 tabs: Siparişler, Personel, Bildirimler)
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.TableChart, contentDescription = "Siparişler") },
                        label = { Text("Siparişler & Onay", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_headquarters_table")
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.Engineering, contentDescription = "Ekip") },
                        label = { Text("Personel", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_headquarters_staff")
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge { Text("$unreadCount") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Notifications, contentDescription = "Bildirimler")
                            }
                        },
                        label = { Text("Bildirimler", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_headquarters_notifications")
                    )
                } else {
                    // Saha Personeli Tab Bar (3 tabs: Siparişlerim, Yeni Talep, Bildirimler)
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.ListAlt, contentDescription = "Taleplerim") },
                        label = { Text("Siparişlerim", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_tech_orders")
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.AddCircle, contentDescription = "Yeni Talep") },
                        label = { Text("Yeni Sipariş", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_tech_new")
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = {
                            BadgedBox(
                                badge = {
                                    if (unreadCount > 0) {
                                        Badge { Text("$unreadCount") }
                                    }
                                }
                            ) {
                                Icon(Icons.Default.Notifications, contentDescription = "Bildirimler")
                            }
                        },
                        label = { Text("Bildirimler", fontSize = 11.sp) },
                        modifier = Modifier.testTag("nav_tech_notifications")
                    )
                }
            }
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            Column(modifier = Modifier.fillMaxSize()) {
                // In-App Notification Banner drops down here when status changes
                InAppNotificationBanner(
                    notification = activeBanner,
                    onViewDetail = {
                        if (activeBanner != null) {
                            viewModel.openOrderByNotification(activeBanner!!)
                        }
                    },
                    onDismiss = { viewModel.dismissBanner() }
                )

                // Tab Content Switcher based on Active Role
                Box(modifier = Modifier.weight(1f)) {
                    if (currentRole == UserRole.HEADQUARTERS) {
                        when (selectedTab) {
                            0 -> AdvancedSearchTableView(viewModel = viewModel)
                            1 -> FieldStaffManagementScreen(viewModel = viewModel)
                            2 -> NotificationsScreen(viewModel = viewModel)
                            else -> AdvancedSearchTableView(viewModel = viewModel)
                        }
                    } else {
                        when (selectedTab) {
                            0 -> OrdersListScreen(
                                viewModel = viewModel,
                                onNavigateToNewRequest = { selectedTab = 1 }
                            )
                            1 -> NewRequestScreen(
                                viewModel = viewModel,
                                onSuccessNav = { selectedTab = 0 }
                            )
                            2 -> NotificationsScreen(viewModel = viewModel)
                            else -> OrdersListScreen(
                                viewModel = viewModel,
                                onNavigateToNewRequest = { selectedTab = 1 }
                            )
                        }
                    }
                }
            }

            // Order Detail Dialog / Full Sheet
            selectedOrder?.let { order ->
                OrderDetailModal(
                    order = order,
                    currentRole = currentRole,
                    onDismiss = { viewModel.selectOrder(null) },
                    onMarkOrderPlaced = { supplier, refNumber, notes ->
                        viewModel.markOrderPlaced(order, supplier, refNumber, notes)
                    },
                    onMarkOrderDelivered = { arrivedPhotoUri, arrivalNotes ->
                        viewModel.markOrderDelivered(order, arrivedPhotoUri, arrivalNotes)
                    },
                    onSnooze = {
                        viewModel.snoozeOrder(order, 3)
                        viewModel.selectOrder(null)
                    }
                )
            }
        }
    }
}
