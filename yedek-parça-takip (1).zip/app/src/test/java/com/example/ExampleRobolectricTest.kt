package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.OrderStatus
import com.example.data.model.PartOrderRequest
import com.example.data.model.PredefinedAccounts
import com.example.data.model.SparePartItem
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    @Test
    fun `read app_name string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("Yedek Parça Takip", appName)
    }

    @Test
    fun `order status transitions and label generation`() {
        assertEquals("Beklemede (Talep Alındı)", OrderStatus.getLabel(OrderStatus.PENDING))
        assertEquals("Sipariş Geçildi", OrderStatus.getLabel(OrderStatus.ORDERED))
        assertEquals("Parça Geldi / Teslim Edildi", OrderStatus.getLabel(OrderStatus.DELIVERED))
    }

    @Test
    fun `part order request creation with stock deduction`() {
        val request = PartOrderRequest(
            customerName = "Hasan Kaya",
            customerPhone = "0533 111 2233",
            customerAddress = "İzmir",
            deviceType = "Klima",
            deviceModel = "Daikin Sensira",
            faultDescription = "Soğutmuyor",
            requiredPartName = "Dört Yollu Vana",
            isStockDeducted = true,
            partQuantity = 1
        )
        assertNotNull(request)
        assertEquals("Hasan Kaya", request.customerName)
        assertEquals(OrderStatus.PENDING, request.status)
        assertTrue(request.isStockDeducted)
    }

    @Test
    fun `spare part critical stock detection`() {
        val criticalPart = SparePartItem(
            partCode = "CRIT-01",
            partName = "Test Kartı",
            category = "Kombi",
            stockQuantity = 2,
            minCriticalLevel = 3
        )
        assertTrue(criticalPart.isCritical)

        val outOfStockPart = SparePartItem(
            partCode = "OUT-01",
            partName = "Fan Motoru",
            category = "Klima",
            stockQuantity = 0,
            minCriticalLevel = 2
        )
        assertTrue(outOfStockPart.isOutOfStock)
    }

    @Test
    fun `authentication with predefined accounts`() {
        val techAuth = PredefinedAccounts.authenticate("ahmet.usta", "1234")
        assertNotNull(techAuth)
        assertEquals("Ahmet Yılmaz (Saha 1)", techAuth?.fullName)

        val adminAuth = PredefinedAccounts.authenticate("merkez.admin", "admin123")
        assertNotNull(adminAuth)
    }

    @Test
    fun `field staff member entity creation and validation`() {
        val staff = com.example.data.model.FieldStaffMember(
            staffId = "tech_test",
            fullName = "Serkan Kaya",
            username = "serkan.kaya",
            password = "password123",
            phone = "0555 123 4567",
            title = "Klima & Beyaz Eşya Uzmanı"
        )
        assertNotNull(staff)
        assertEquals("Serkan Kaya", staff.fullName)
        assertEquals("serkan.kaya", staff.username)
        assertEquals("password123", staff.password)
        assertTrue(staff.isActive)
    }

    @Test
    fun `order overdue detection and 3-day snooze logic`() {
        val now = System.currentTimeMillis()
        val fourDaysAgo = now - (4 * 24 * 3600 * 1000L)

        val overdueOrder = PartOrderRequest(
            customerName = "Kadir Şimşek",
            customerPhone = "0544 555 6677",
            customerAddress = "Ankara",
            deviceType = "Kombi",
            deviceModel = "Demirdöküm Nitromix",
            faultDescription = "Alev kaybı",
            requiredPartName = "Sirkülasyon Pompası",
            status = OrderStatus.ORDERED,
            orderPlacedAt = fourDaysAgo,
            createdAt = fourDaysAgo
        )

        // Must be overdue because 4 days > 3 days and not delivered
        assertTrue(overdueOrder.isOverdue)
        assertTrue(overdueOrder.overdueDaysCount >= 4)
        // Not snoozed initially
        org.junit.Assert.assertFalse(overdueOrder.isSnoozed)

        // When snoozed for 3 days
        val snoozedOrder = overdueOrder.copy(
            snoozedUntil = now + (3 * 24 * 3600 * 1000L)
        )
        assertTrue(snoozedOrder.isSnoozed)

        // When delivered, never overdue
        val deliveredOrder = overdueOrder.copy(status = OrderStatus.DELIVERED)
        org.junit.Assert.assertFalse(deliveredOrder.isOverdue)
    }
}
