const http = require('http');
const fs = require('fs');
const path = require('path');

const PORT = 3000;
const PUBLIC_DIR = path.join(__dirname, 'web_dist');
const DB_FILE = path.join(__dirname, 'orders_db.json');
const USERS_FILE = path.join(__dirname, 'users_db.json');

// MIME types
const MIME_TYPES = {
  '.html': 'text/html; charset=UTF-8',
  '.js': 'application/javascript; charset=UTF-8',
  '.css': 'text/css; charset=UTF-8',
  '.json': 'application/json; charset=UTF-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.svg': 'image/svg+xml',
  '.apk': 'application/vnd.android.package-archive',
};

// Users database
let users = [];
try {
  if (fs.existsSync(USERS_FILE)) {
    users = JSON.parse(fs.readFileSync(USERS_FILE, 'utf-8'));
    console.log(`Loaded ${users.length} users from store.`);
  } else {
    users = [];
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  }
} catch (e) {
  console.error("Users DB init error:", e);
}

function saveUsersDb() {
  try {
    fs.writeFileSync(USERS_FILE, JSON.stringify(users, null, 2));
  } catch (e) {
    console.error("Error saving users DB:", e);
  }
}

// Initial in-memory database with persistent backup
let orders = [];
try {
  if (fs.existsSync(DB_FILE)) {
    orders = JSON.parse(fs.readFileSync(DB_FILE, 'utf-8'));
    console.log(`Loaded ${orders.length} orders from persistent store.`);
  } else {
    orders = [];
    fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
  }
} catch (e) {
  console.error("DB init error:", e);
}

// Keep-alive heartbeat to keep server awake and responsive
setInterval(() => {
  try {
    const req = http.get('http://localhost:3000/api/users', () => {});
    req.on('error', () => {});
  } catch (_) {}
}, 120000);

function saveDb() {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(orders, null, 2));
  } catch (e) {
    console.error("Error saving DB:", e);
  }
}

// SSE Event Stream subscribers
const sseClients = new Set();
function broadcastEvent(type, data) {
  const payload = `event: ${type}\ndata: ${JSON.stringify(data)}\n\n`;
  for (const client of sseClients) {
    try {
      client.write(payload);
    } catch (e) {
      sseClients.delete(client);
    }
  }
}

const server = http.createServer((req, res) => {
  // CORS headers
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type, Authorization');

  if (req.method === 'OPTIONS') {
    res.writeHead(204);
    res.end();
    return;
  }

  const parsedUrl = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = parsedUrl.pathname;

  // --- API ROUTES ---

  // Real-time Server-Sent Events (SSE) endpoint for Web Portal
  if (pathname === '/api/orders/events' && req.method === 'GET') {
    res.writeHead(200, {
      'Content-Type': 'text/event-stream',
      'Cache-Control': 'no-cache, no-transform',
      'Connection': 'keep-alive',
      'Access-Control-Allow-Origin': '*'
    });
    res.write(`data: ${JSON.stringify({ type: 'connected', time: Date.now() })}\n\n`);
    sseClients.add(res);

    req.on('close', () => {
      sseClients.delete(res);
    });
    return;
  }

  // GET /api/orders -> List all orders
  if (pathname === '/api/orders' && req.method === 'GET') {
    const techId = parsedUrl.searchParams.get('technicianId');
    let result = orders;
    if (techId) {
      result = orders.filter(o => o.technicianId === techId);
    }
    res.writeHead(200, { 'Content-Type': 'application/json; charset=UTF-8' });
    res.end(JSON.stringify(result));
    return;
  }

  // POST /api/orders -> Create or update order from mobile technician
  if (pathname === '/api/orders' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const orderData = JSON.parse(body);
        if (!orderData.id) {
          orderData.id = Date.now();
        }
        if (!orderData.createdAt) {
          orderData.createdAt = Date.now();
        }
        if (!orderData.status) {
          orderData.status = 'BEKLEMEDE';
        }

        const existingIndex = orders.findIndex(o => o.id == orderData.id);
        let isNew = false;
        if (existingIndex >= 0) {
          orders[existingIndex] = { ...orders[existingIndex], ...orderData };
        } else {
          orders.unshift(orderData);
          isNew = true;
        }

        saveDb();

        // Broadcast real-time event to web portal
        broadcastEvent(isNew ? 'order_created' : 'order_updated', orderData);

        res.writeHead(200, { 'Content-Type': 'application/json; charset=UTF-8' });
        res.end(JSON.stringify({ success: true, order: orderData, isNew }));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid JSON payload: ' + err.message }));
      }
    });
    return;
  }

  // POST /api/orders/sync -> Batch sync offline orders when mobile reconnects
  if (pathname === '/api/orders/sync' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const batch = JSON.parse(body);
        if (Array.isArray(batch)) {
          let updatedCount = 0;
          for (const orderData of batch) {
            const idx = orders.findIndex(o => o.id == orderData.id);
            if (idx >= 0) {
              orders[idx] = { ...orders[idx], ...orderData };
            } else {
              orders.unshift(orderData);
            }
            updatedCount++;
          }
          saveDb();
          broadcastEvent('orders_synced', { count: updatedCount, orders });
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, synced: updatedCount }));
        } else {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Expected array of orders' }));
        }
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // POST /api/orders/:id/approve -> Center manager approves order
  const approveMatch = pathname.match(/^\/api\/orders\/([^\/]+)\/approve$/);
  if (approveMatch && req.method === 'POST') {
    const orderId = approveMatch[1];
    const order = orders.find(o => o.id == orderId);
    if (!order) {
      res.writeHead(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Order not found' }));
      return;
    }
    order.status = 'ONAYLANDI';
    order.approvedAt = Date.now();
    order.orderPlacedAt = Date.now();
    saveDb();

    broadcastEvent('order_approved', order);

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true, order }));
    return;
  }

  // POST /api/orders/:id/status -> Update status
  const statusMatch = pathname.match(/^\/api\/orders\/([^\/]+)\/status$/);
  if (statusMatch && req.method === 'POST') {
    const orderId = statusMatch[1];
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { status, notes } = JSON.parse(body);
        const order = orders.find(o => o.id == orderId);
        if (!order) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Order not found' }));
          return;
        }
        order.status = status;
        if (notes) order.orderNotes = notes;
        if (status === 'TESLIM_EDILDI') {
          order.arrivedAt = Date.now();
        }
        saveDb();
        broadcastEvent('order_status_changed', order);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, order }));
      } catch (e) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e.message }));
      }
    });
    return;
  }

  // POST /api/orders/:id/snooze -> Snooze 3 days
  const snoozeMatch = pathname.match(/^\/api\/orders\/([^\/]+)\/snooze$/);
  if (snoozeMatch && req.method === 'POST') {
    const orderId = snoozeMatch[1];
    const order = orders.find(o => o.id == orderId);
    if (order) {
      const threeDaysMs = 3 * 24 * 3600 * 1000;
      order.snoozedUntil = Date.now() + threeDaysMs;
      saveDb();
      broadcastEvent('order_snoozed', order);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true, order }));
      return;
    }
  }

  // GET /api/auth/status -> Check if any users exist
  if (pathname === '/api/auth/status' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=UTF-8' });
    res.end(JSON.stringify({ hasUsers: users.length > 0, totalUsers: users.length }));
    return;
  }

  // POST /api/auth/login -> Web portal authentication
  if (pathname === '/api/auth/login' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { username, password } = JSON.parse(body);
        if (users.length === 0) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, isEmpty: true, error: 'Sistemde kayıtlı kullanıcı bulunmuyor. Lütfen ilk yönetici hesabınızı oluşturun.' }));
          return;
        }
        const cleanUser = (username || '').trim().toLowerCase();
        const cleanPass = (password || '').trim();
        const user = users.find(u => {
          const dbUser = (u.username || '').toLowerCase().trim();
          const matchesUser = dbUser === cleanUser || 
                              dbUser.replace(/\.+$/, '') === cleanUser.replace(/\.+$/, '') ||
                              dbUser.replace(/\./g, '') === cleanUser.replace(/\./g, '');
          return matchesUser && String(u.password).trim() === cleanPass;
        });
        if (user) {
          const safeUser = {
            username: user.username,
            fullName: user.fullName,
            role: user.role || 'HEADQUARTERS',
            phone: user.phone || '',
            email: user.email || '',
            technicianId: user.technicianId || ''
          };
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: true, user: safeUser }));
        } else {
          res.writeHead(401, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ success: false, error: 'Kullanıcı adı veya şifre hatalı!' }));
        }
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // POST /api/auth/setup-admin -> First time admin setup if no users
  if (pathname === '/api/auth/setup-admin' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { username, password, fullName, phone, email, masterPin } = JSON.parse(body);
        if (users.length > 0 && masterPin !== 'CAGTEKNIK-2026') {
          res.writeHead(403, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Sistemde zaten kullanıcı kayıtlı. Yeni kullanıcı eklemek için giriş yapınız veya Ana Kurtarma PIN kodunu giriniz.' }));
          return;
        }
        if (!username || !password || !fullName) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Ad Soyad, kullanıcı adı ve şifre zorunludur.' }));
          return;
        }
        const cleanUser = username.trim().toLowerCase();
        const newAdmin = {
          fullName: fullName.trim(),
          username: cleanUser,
          password: password.trim(),
          phone: (phone || '').trim(),
          email: (email || '').trim(),
          role: 'HEADQUARTERS',
          technicianId: 'admin_' + cleanUser.replace(/[^a-z0-9]/g, '_')
        };
        const existingIdx = users.findIndex(u => {
          const uName = (u.username || '').toLowerCase().trim();
          return uName === cleanUser || uName.replace(/\.+$/, '') === cleanUser.replace(/\.+$/, '');
        });
        if (existingIdx >= 0) {
          users[existingIdx] = newAdmin;
        } else {
          users.push(newAdmin);
        }
        saveUsersDb();
        broadcastEvent('users_updated', { users });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, user: newAdmin }));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // POST /api/auth/recover -> Password recovery
  if (pathname === '/api/auth/recover' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const { username, phone, recoveryKey, newPassword } = JSON.parse(body);
        if (!username || !newPassword) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Kullanıcı adı ve yeni şifre zorunludur.' }));
          return;
        }
        const cleanUser = username.trim().toLowerCase();
        const user = users.find(u => {
          const dbUser = (u.username || '').toLowerCase().trim();
          return dbUser === cleanUser || 
                 dbUser.replace(/\.+$/, '') === cleanUser.replace(/\.+$/, '') ||
                 dbUser.replace(/\./g, '') === cleanUser.replace(/\./g, '');
        });
        if (!user) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Belirtilen kullanıcı sistemde bulunamadı.' }));
          return;
        }

        const isMasterKey = (recoveryKey || '').trim() === 'CAGTEKNIK-2026';
        const cleanReqPhone = (phone || '').replace(/[^0-9]/g, '');
        const cleanUserPhone = (user.phone || '').replace(/[^0-9]/g, '');
        const isPhoneMatch = cleanReqPhone.length >= 7 && cleanUserPhone.endsWith(cleanReqPhone.slice(-7));

        if (!isMasterKey && !isPhoneMatch) {
          res.writeHead(403, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Telefon numarası veya kurtarma anahtarı eşleşmedi. Lütfen kayıtlı telefonunuzu veya Ana Kurtarma Kodunu (CAGTEKNIK-2026) giriniz.' }));
          return;
        }

        user.password = newPassword.trim();
        saveUsersDb();
        broadcastEvent('users_updated', { users });

        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, message: 'Şifreniz başarıyla sıfırlandı. Yeni şifrenizle giriş yapabilirsiniz.' }));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // GET /api/users -> List all users/technicians
  if (pathname === '/api/users' && req.method === 'GET') {
    res.writeHead(200, { 'Content-Type': 'application/json; charset=UTF-8' });
    res.end(JSON.stringify(users));
    return;
  }

  // POST /api/users -> Create or update user/technician
  if (pathname === '/api/users' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => { body += chunk; });
    req.on('end', () => {
      try {
        const userData = JSON.parse(body);
        if (!userData.username || !userData.username.trim()) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Username is required' }));
          return;
        }
        const cleanUser = userData.username.trim().toLowerCase();
        userData.username = cleanUser;
        if (!userData.technicianId) {
          userData.technicianId = 'tech_' + cleanUser.replace(/[^a-z0-9]/g, '_');
        }
        const idx = users.findIndex(u => {
          const uName = (u.username || '').toLowerCase().trim();
          return uName === cleanUser || 
                 uName.replace(/\.+$/, '') === cleanUser.replace(/\.+$/, '') ||
                 uName.replace(/\./g, '') === cleanUser.replace(/\./g, '');
        });
        if (idx >= 0) {
          users[idx] = { ...users[idx], ...userData };
        } else {
          users.push(userData);
        }
        saveUsersDb();
        broadcastEvent('users_updated', { users });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, user: userData }));
      } catch (err) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: err.message }));
      }
    });
    return;
  }

  // DELETE /api/users/:username -> Delete user
  const deleteUserMatch = pathname.match(/^\/api\/users\/([^\/]+)$/);
  if (deleteUserMatch && req.method === 'DELETE') {
    const targetUser = decodeURIComponent(deleteUserMatch[1]).toLowerCase().trim();
    users = users.filter(u => {
      const uName = (u.username || '').toLowerCase().trim();
      return uName !== targetUser && 
             uName.replace(/\.+$/, '') !== targetUser.replace(/\.+$/, '') &&
             uName.replace(/\./g, '') !== targetUser.replace(/\./g, '');
    });
    saveUsersDb();
    broadcastEvent('users_updated', { users });
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ success: true }));
    return;
  }

  // --- STATIC FILE SERVING ---
  let reqPath = decodeURI(pathname);
  if (reqPath === '/' || reqPath === '') {
    reqPath = '/index.html';
  }

  const filePath = path.join(PUBLIC_DIR, reqPath);

  // Security: prevent path traversal
  if (!filePath.startsWith(PUBLIC_DIR)) {
    res.writeHead(403);
    res.end('Access Denied');
    return;
  }

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      // Fallback to index.html for SPA routing
      const fallback = path.join(PUBLIC_DIR, 'index.html');
      fs.readFile(fallback, (fErr, content) => {
        if (fErr) {
          res.writeHead(404);
          res.end('Not Found');
        } else {
          res.writeHead(200, { 'Content-Type': 'text/html; charset=UTF-8' });
          res.end(content);
        }
      });
      return;
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'application/octet-stream';

    // HTTP Byte-Range requests
    const range = req.headers.range;
    if (range) {
      const parts = range.replace(/bytes=/, "").split("-");
      const start = parseInt(parts[0], 10);
      const end = parts[1] ? parseInt(parts[1], 10) : stats.size - 1;
      const chunksize = (end - start) + 1;
      const fileStream = fs.createReadStream(filePath, { start, end });
      const head = {
        'Content-Range': `bytes ${start}-${end}/${stats.size}`,
        'Accept-Ranges': 'bytes',
        'Content-Length': chunksize,
        'Content-Type': contentType,
      };
      if (ext === '.apk') {
        head['Content-Disposition'] = 'attachment; filename="YedekParcaTakip.apk"';
      }
      res.writeHead(206, head);
      fileStream.pipe(res);
      return;
    }

    const headers = {
      'Content-Type': contentType,
      'Content-Length': stats.size,
      'Accept-Ranges': 'bytes',
    };

    if (ext === '.apk') {
      headers['Content-Disposition'] = 'attachment; filename="YedekParcaTakip.apk"';
    }

    res.writeHead(200, headers);
    fs.createReadStream(filePath).pipe(res);
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Backend API & Web server listening on http://0.0.0.0:${PORT}`);
});
